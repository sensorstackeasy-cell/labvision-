import { test } from "node:test";
import assert from "node:assert/strict";
import { lines, oneLine, paragraphs, parseSpecs, specsToText } from "../src/lib/text";

test("parseSpecs reads Label | Value lines and skips junk", () => {
  assert.deepEqual(parseSpecs("Modes | VCV, PCV\nnot a spec\n | empty label\nPEEP | 0 | 30"), [["Modes", "VCV, PCV"], ["PEEP", "0 | 30"]]);
});
test("specs round trip", () => { const s: [string, string][] = [["A", "1"], ["B", "2"]]; assert.deepEqual(parseSpecs(specsToText(s)), s); });
test("paragraphs split on blank lines", () => assert.deepEqual(paragraphs("one\nstill one\n\ntwo"), ["one\nstill one", "two"]));
test("lines trims and drops empties", () => assert.deepEqual(lines(" a \n\n b\n"), ["a", "b"]));
test("oneLine removes header-injection characters", () => assert.equal(oneLine("Hi\r\nBcc: x@y.z"), "Hi Bcc: x@y.z"));
