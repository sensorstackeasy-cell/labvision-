import { test } from "node:test";
import assert from "node:assert/strict";
import { plan } from "../src/lib/planner";
import { csvCell, toCsv } from "../src/lib/csv";

test("plan rounds up and never returns zero for a non-empty unit", () => {
  assert.deepEqual(plan(10, "icu"), { monitors: 10, ventilators: 6 });
  assert.deepEqual(plan(1, "ward"), { monitors: 1, ventilators: 1 });
});
test("plan handles zero, negative and huge input", () => {
  assert.deepEqual(plan(0, "icu"), { monitors: 0, ventilators: 0 });
  assert.deepEqual(plan(-5, "icu"), { monitors: 0, ventilators: 0 });
  assert.equal(plan(99999, "icu").monitors, 500);
});
test("csv quotes commas and neutralises spreadsheet formulas", () => {
  assert.equal(csvCell('a,"b"'), '"a,""b"""');
  assert.equal(csvCell("=HYPERLINK(1)"), "'=HYPERLINK(1)");
  assert.equal(toCsv([["x", 1], ["y,z", null]]), 'x,1\r\n"y,z",');
});
