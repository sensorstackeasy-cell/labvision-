import { test } from "node:test";
import assert from "node:assert/strict";
import { base32Decode, base32Encode, totpAt, verifyTotp } from "../src/lib/totp";

const secret = Buffer.from("12345678901234567890"); // RFC 6238 test secret

test("RFC 6238 test vectors (SHA-1, 8 digits)", () => {
  assert.equal(totpAt(secret, 59_000, 8), "94287082");
  assert.equal(totpAt(secret, 1111111109_000, 8), "07081804");
  assert.equal(totpAt(secret, 1234567890_000, 8), "89005924");
});
test("base32 round trip", () => assert.equal(base32Decode(base32Encode(secret)).toString(), secret.toString()));
test("verifyTotp accepts the current code and one step of drift, rejects others", () => {
  const b32 = base32Encode(secret), now = 1111111109_000, code = totpAt(secret, now);
  assert.equal(verifyTotp(b32, code, now), true);
  assert.equal(verifyTotp(b32, code, now + 30_000), true);
  assert.equal(verifyTotp(b32, code, now + 90_000), false);
  assert.equal(verifyTotp(b32, "abcdef", now), false);
});
