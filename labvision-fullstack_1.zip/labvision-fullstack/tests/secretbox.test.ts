import { test } from "node:test";
import assert from "node:assert/strict";
import { open, seal } from "../src/lib/secretbox";

const key = Buffer.alloc(32, 7).toString("base64");

test("seal and open round trip", () => assert.equal(open(seal("JBSWY3DPEHPK3PXP", key), key), "JBSWY3DPEHPK3PXP"));
test("a tampered value is rejected", () => {
  const s = Buffer.from(seal("secret", key), "base64"); s[s.length - 1] ^= 1;
  assert.throws(() => open(s.toString("base64"), key));
});
test("a wrong key is rejected", () => assert.throws(() => open(seal("secret", key), Buffer.alloc(32, 9).toString("base64"))));
