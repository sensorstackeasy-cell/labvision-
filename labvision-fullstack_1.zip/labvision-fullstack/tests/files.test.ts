import { test } from "node:test";
import assert from "node:assert/strict";
import { detectCv, CV_MAX_BYTES, safeFilename } from "../src/lib/files";

const pdf = Uint8Array.from([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x37]);
const zip = Uint8Array.from([0x50, 0x4b, 0x03, 0x04, 0x14, 0x00]);

test("accepts a real PDF with a matching extension", () => assert.equal(detectCv(pdf, "My CV.PDF")?.ext, "pdf"));
test("accepts a DOCX (zip signature) with a .docx extension", () => assert.equal(detectCv(zip, "cv.docx")?.ext, "docx"));
test("rejects a PDF that is named .exe", () => assert.equal(detectCv(pdf, "cv.exe"), null));
test("rejects a script renamed to .pdf", () => assert.equal(detectCv(new TextEncoder().encode("<script>alert(1)</script>"), "cv.pdf"), null));
test("rejects an empty file and an oversize file", () => {
  assert.equal(detectCv(new Uint8Array(0), "cv.pdf"), null);
  const big = new Uint8Array(CV_MAX_BYTES + 1); big.set(pdf);
  assert.equal(detectCv(big, "cv.pdf"), null);
});
test("safeFilename removes path and quote characters", () => assert.equal(safeFilename('../../etc/pass"wd.pdf'), ".._.._etc_pass_wd.pdf"));
