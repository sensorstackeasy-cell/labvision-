import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { allow, resetRateLimits } from "../src/lib/ratelimit";

beforeEach(() => resetRateLimits());

test("allows up to the limit then blocks", () => {
  for (let i = 0; i < 3; i++) assert.equal(allow("ip1", 3, 1000, 100), true);
  assert.equal(allow("ip1", 3, 1000, 100), false);
});
test("keys are independent", () => {
  for (let i = 0; i < 3; i++) allow("a", 3, 1000, 100);
  assert.equal(allow("b", 3, 1000, 100), true);
});
test("the window slides: old hits expire", () => {
  for (let i = 0; i < 3; i++) allow("c", 3, 1000, 0);
  assert.equal(allow("c", 3, 1000, 500), false);
  assert.equal(allow("c", 3, 1000, 1001), true);
});
