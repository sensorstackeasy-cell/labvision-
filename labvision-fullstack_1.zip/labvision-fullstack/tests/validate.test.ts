// Needs dependencies installed (zod). Run with `npm test` after `npm install`.
import { test } from "node:test";
import assert from "node:assert/strict";
import { applicationSchema, enquirySchema } from "../src/lib/validate";

const ok = { kind: "quotation", name: "Asha Rao", email: "ASHA@Example.com", phone: "+91 98765 43210", consent: true };

test("accepts a valid enquiry and lower-cases the email", () => {
  const r = enquirySchema.safeParse(ok);
  assert.equal(r.success, true);
  if (r.success) assert.equal(r.data.email, "asha@example.com");
});
test("rejects without consent", () => assert.equal(enquirySchema.safeParse({ ...ok, consent: false }).success, false));
test("rejects an unknown kind", () => assert.equal(enquirySchema.safeParse({ ...ok, kind: "admin" }).success, false));
test("rejects a bad phone number and oversize messages", () => {
  assert.equal(enquirySchema.safeParse({ ...ok, phone: "abc" }).success, false);
  assert.equal(enquirySchema.safeParse({ ...ok, message: "x".repeat(3001) }).success, false);
});
test("application needs a 10-digit phone and an https link", () => {
  const app = { role: "Intern", name: "Ravi", email: "r@x.co", phone: "9876543210", consent: true };
  assert.equal(applicationSchema.safeParse(app).success, true);
  assert.equal(applicationSchema.safeParse({ ...app, phone: "12345" }).success, false);
  assert.equal(applicationSchema.safeParse({ ...app, link: "javascript:alert(1)" }).success, false);
});
