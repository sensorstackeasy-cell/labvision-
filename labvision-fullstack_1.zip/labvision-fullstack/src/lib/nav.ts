export type NavItem = { label: string; href: string; c?: string };

export function buildNav(products: { slug: string; name: string; accent: string }[], hasNews: boolean): NavItem[] {
  return [
    { label: "Home", href: "/" }, { label: "About us", href: "/about" },
    ...products.map((p) => ({ label: p.name, href: `/products/${p.slug}`, c: p.accent })),
    { label: "Catalog and downloads", href: "/catalog" }, { label: "Service and support", href: "/service" }, { label: "FAQ", href: "/faq" },
    { label: "Distributors", href: "/distributors" }, { label: "Leadership", href: "/leadership" }, { label: "Careers", href: "/careers" },
    { label: "Quality and compliance", href: "/quality" }, { label: "Certificates and documents", href: "/certificates" },
    { label: "Request a demo", href: "/demo" }, { label: "Planning guide", href: "/planner" }, { label: "Tenders and GeM", href: "/tenders" },
    ...(hasNews ? [{ label: "News", href: "/news" }] : []), { label: "Track a request", href: "/track" }, { label: "Contact and locations", href: "/contact" },
  ];
}
