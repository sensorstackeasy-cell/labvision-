import postgres from "postgres";

const g = globalThis as unknown as { __sql?: ReturnType<typeof postgres> };
export const sql = g.__sql ?? postgres(process.env.DATABASE_URL ?? "", { max: 10, idle_timeout: 20 });
if (process.env.NODE_ENV !== "production") g.__sql = sql;
export const j = (v: unknown) => sql.json(v as postgres.JSONValue);
