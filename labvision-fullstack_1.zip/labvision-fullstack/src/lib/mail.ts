import nodemailer from "nodemailer";
import { oneLine } from "./text";

const smtp = process.env.SMTP_HOST
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT ?? 587),
      secure: process.env.SMTP_PORT === "465",
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    })
  : null;

/**
 * Sends a notification to the company mailbox (MAIL_TO, for example sales@labvision.co.in).
 * Uses SMTP when SMTP_HOST is set, otherwise Web3Forms when WEB3FORMS_KEY is set. Throws if delivery fails,
 * so callers can log it. The enquiry is already saved in the database before this runs, so nothing is lost.
 */
export async function notify(subject: string, body: string, replyTo?: string): Promise<"smtp" | "web3forms" | "skipped"> {
  if (smtp && process.env.MAIL_TO) {
    await smtp.sendMail({ from: process.env.MAIL_FROM ?? process.env.MAIL_TO, to: process.env.MAIL_TO, subject: oneLine(subject), text: body, replyTo });
    return "smtp";
  }
  const key = process.env.WEB3FORMS_KEY;
  if (key) {
    const r = await fetch("https://api.web3forms.com/submit", {
      method: "POST", headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ access_key: key, subject: oneLine(subject), from_name: "Labvision MedTech website", ...(replyTo ? { email: replyTo } : {}), message: body }),
    });
    const j = (await r.json().catch(() => null)) as { success?: boolean; message?: string } | null;
    if (!r.ok || !j?.success) throw new Error(`Web3Forms rejected the message: ${j?.message ?? r.status}`);
    return "web3forms";
  }
  console.warn("Email skipped: set SMTP_HOST and MAIL_TO, or WEB3FORMS_KEY");
  return "skipped";
}
