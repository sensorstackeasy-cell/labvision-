export type Unit = "icu" | "hdu" | "ward" | "emergency";
// Planning ratios are a starting point for a conversation, not clinical guidance. The hospital's clinical team decides.
const RATIOS: Record<Unit, { monitors: number; ventilators: number }> = {
  icu: { monitors: 1, ventilators: 0.6 }, hdu: { monitors: 1, ventilators: 0.25 }, ward: { monitors: 0.25, ventilators: 0.05 }, emergency: { monitors: 1, ventilators: 0.3 },
};
export function plan(beds: number, unit: Unit): { monitors: number; ventilators: number } {
  const n = Math.max(0, Math.min(500, Math.floor(beds)));
  const r = RATIOS[unit];
  return { monitors: n === 0 ? 0 : Math.max(1, Math.ceil(n * r.monitors)), ventilators: n === 0 ? 0 : Math.max(1, Math.ceil(n * r.ventilators)) };
}
