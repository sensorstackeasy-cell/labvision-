/** "Label | Value" per line to [label, value] pairs. Lines without a separator are ignored. */
export function parseSpecs(text: string): [string, string][] {
  return text.split(/\r?\n/).map((l) => l.split("|")).filter((p) => p.length >= 2 && p[0].trim())
    .map((p) => [p[0].trim(), p.slice(1).join("|").trim()] as [string, string]).slice(0, 40);
}
export const lines = (text: string): string[] => text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).slice(0, 40);
export const paragraphs = (text: string): string[] => text.split(/\r?\n\s*\r?\n/).map((l) => l.trim()).filter(Boolean).slice(0, 10);
export const specsToText = (s: [string, string][]) => s.map(([a, b]) => `${a} | ${b}`).join("\n");
export const oneLine = (s: string) => s.replace(/[\r\n]+/g, " ").slice(0, 200);
