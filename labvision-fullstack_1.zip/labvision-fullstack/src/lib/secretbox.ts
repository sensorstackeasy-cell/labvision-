import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

// APP_ENC_KEY: 32 random bytes, base64. Generate with: openssl rand -base64 32
const key = (k = process.env.APP_ENC_KEY ?? "") => { const b = Buffer.from(k, "base64"); if (b.length !== 32) throw new Error("APP_ENC_KEY must be 32 bytes, base64"); return b; };

export function seal(plain: string, k?: string): string {
  const iv = randomBytes(12), c = createCipheriv("aes-256-gcm", key(k), iv);
  const enc = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), enc]).toString("base64");
}
export function open(sealed: string, k?: string): string {
  const b = Buffer.from(sealed, "base64"), d = createDecipheriv("aes-256-gcm", key(k), b.subarray(0, 12));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString("utf8");
}
