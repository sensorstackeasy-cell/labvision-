import { z } from "zod";

const text = (max: number) => z.string().trim().max(max);
const phone = z.string().trim().max(20).regex(/^[+0-9\s()-]{7,20}$/, "Enter a valid phone number").or(z.literal(""));
const email = z.string().trim().toLowerCase().email("Enter a valid email address").max(200);

export const enquirySchema = z.object({
  kind: z.enum(["contact", "quotation", "service", "document", "distributor", "demo"]),
  name: text(100).min(2, "Enter your name"),
  email,
  phone,
  organisation: text(150).default(""),
  product: text(120).default(""),
  message: text(3000).default(""),
  details: z.record(z.string().max(300)).refine((o) => Object.keys(o).length <= 10, "Too many fields").default({}),
  consent: z.literal(true, { errorMap: () => ({ message: "Please tick the box to agree to be contacted" }) }),
});

export const applicationSchema = z.object({
  role: text(120).min(2),
  name: text(100).min(2, "Enter your name"),
  email,
  phone: phone.refine((p) => p.replace(/\D/g, "").length >= 10, "Enter a 10-digit phone number"),
  experience: text(40).default(""),
  city: text(80).default(""),
  qualification: text(150).default(""),
  link: text(300).refine((v) => v === "" || /^https?:\/\//i.test(v), "Link must start with https://").default(""),
  message: text(3000).default(""),
  consent: z.literal(true, { errorMap: () => ({ message: "Please tick the box to agree to be contacted" }) }),
});

export const firstError = (e: z.ZodError): string => e.issues[0]?.message ?? "Please check the form";
