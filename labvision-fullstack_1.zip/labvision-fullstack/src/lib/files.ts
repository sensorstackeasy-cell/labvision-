export const CV_MAX_BYTES = 5 * 1024 * 1024;

const SIGNATURES = [
  { ext: "pdf", mime: "application/pdf", bytes: [0x25, 0x50, 0x44, 0x46] },
  { ext: "docx", mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", bytes: [0x50, 0x4b, 0x03, 0x04] },
  { ext: "doc", mime: "application/msword", bytes: [0xd0, 0xcf, 0x11, 0xe0] },
] as const;

/** Accepts a CV only if size, file extension and the file's first bytes all agree. */
export function detectCv(buf: Uint8Array, filename: string): { ext: string; mime: string } | null {
  if (buf.length === 0 || buf.length > CV_MAX_BYTES) return null;
  const ext = (filename.toLowerCase().split(".").pop() ?? "").trim();
  const s = SIGNATURES.find((x) => x.bytes.every((b, i) => buf[i] === b));
  return s && s.ext === ext ? { ext: s.ext, mime: s.mime } : null;
}

export const safeFilename = (n: string) => n.replace(/[^\w.-]+/g, "_").slice(0, 80) || "cv";
