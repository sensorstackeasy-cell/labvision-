import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { createHash, randomBytes } from "node:crypto";
import { sql } from "./db";
import { audit } from "./audit";
import { open } from "./secretbox";
import { verifyTotp } from "./totp";

export type Role = "admin" | "sales";
export type User = { id: string; email: string; name: string; role: Role; totp_enabled: boolean };
type UserRow = User & { password_hash: string; locked_until: Date | null };

const COOKIE = "lv_session";
const TTL_MS = 8 * 3600 * 1000;
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12); // equalises timing when the email is unknown
const hash = (t: string) => createHash("sha256").update(t).digest("hex");
const token = async () => (await cookies()).get(COOKIE)?.value;

/** Returns "ok", "mfa" (password correct, second step still needed) or "fail". */
export async function login(email: string, password: string): Promise<"ok" | "mfa" | "fail"> {
  const [u] = await sql<UserRow[]>`select id, email, name, role, totp_enabled, password_hash, locked_until from users where lower(email) = lower(${email}) and active`;
  if (!u) { await bcrypt.compare(password, DUMMY_HASH); await audit(null, "login.fail", "user", "", { reason: "unknown" }); return "fail"; }
  if (u.locked_until && u.locked_until > new Date()) { await audit(u.id, "login.blocked", "user", u.id); return "fail"; }
  if (!(await bcrypt.compare(password, u.password_hash))) {
    await sql`update users set failed_logins = failed_logins + 1,
      locked_until = case when failed_logins + 1 >= 5 then now() + interval '15 minutes' else locked_until end where id = ${u.id}`;
    await audit(u.id, "login.fail", "user", u.id);
    return "fail";
  }
  await sql`update users set failed_logins = 0, locked_until = null where id = ${u.id}`;
  await sql`delete from sessions where expires_at < now()`;
  const t = randomBytes(32).toString("base64url");
  await sql`insert into sessions (token_hash, user_id, expires_at, mfa_ok) values (${hash(t)}, ${u.id}, ${new Date(Date.now() + TTL_MS)}, ${!u.totp_enabled})`;
  (await cookies()).set(COOKIE, t, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: TTL_MS / 1000 });
  await audit(u.id, u.totp_enabled ? "login.password_ok" : "login.ok", "user", u.id);
  return u.totp_enabled ? "mfa" : "ok";
}

/** Second step: checks the 6-digit code for the signed-in-but-unverified session. */
export async function verifyMfa(code: string): Promise<boolean> {
  const t = await token(); if (!t) return false;
  const [r] = await sql<{ user_id: string; enc: string | null }[]>`select s.user_id, u.totp_secret_enc as enc from sessions s join users u on u.id = s.user_id
    where s.token_hash = ${hash(t)} and s.expires_at > now() and not s.mfa_ok and u.active`;
  if (!r?.enc || !verifyTotp(open(r.enc), code)) { await audit(r?.user_id ?? null, "mfa.fail", "user", r?.user_id ?? ""); return false; }
  await sql`update sessions set mfa_ok = true where token_hash = ${hash(t)}`;
  await audit(r.user_id, "login.ok", "user", r.user_id);
  return true;
}
export async function hasPendingMfa(): Promise<boolean> {
  const t = await token(); if (!t) return false;
  const [r] = await sql`select 1 from sessions where token_hash = ${hash(t)} and expires_at > now() and not mfa_ok`;
  return !!r;
}

export async function currentUser(): Promise<User | null> {
  const t = await token(); if (!t) return null;
  const [u] = await sql<User[]>`select u.id, u.email, u.name, u.role, u.totp_enabled from sessions s join users u on u.id = s.user_id
    where s.token_hash = ${hash(t)} and s.expires_at > now() and s.mfa_ok and u.active`;
  return u ?? null;
}

/** Call at the top of every admin page and every admin server action. Deny by default. */
export async function requireUser(roles: Role[] = ["admin", "sales"]): Promise<User> {
  const u = await currentUser();
  if (!u) redirect((await hasPendingMfa()) ? "/admin/verify" : "/admin/login");
  if (!roles.includes(u.role)) redirect("/admin");
  return u;
}

export async function logout() {
  const c = await cookies(); const t = c.get(COOKIE)?.value;
  if (t) await sql`delete from sessions where token_hash = ${hash(t)}`;
  c.delete(COOKIE);
}
export async function verifyPassword(userId: string, password: string): Promise<boolean> {
  const [r] = await sql<{ password_hash: string }[]>`select password_hash from users where id = ${userId}`;
  return !!r && bcrypt.compare(password, r.password_hash);
}
