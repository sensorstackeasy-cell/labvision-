export const clientIp = (req: Request) => req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown"; // trust only behind your own proxy/CDN

/** Blocks cross-site form posts to the JSON/multipart endpoints. */
export function sameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin"), site = process.env.SITE_URL;
  if (!origin || !site) return false;
  try { return new URL(origin).origin === new URL(site).origin; } catch { return false; }
}
