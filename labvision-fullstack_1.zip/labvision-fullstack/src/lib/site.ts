export const site = {
  name: "Labvision MedTech",
  phone: "+91 91799 84083",
  tel: "+919179984083",
  whatsapp: "919179984083",
  email: "sales@labvision.co.in",
  address: "Plot No. 82, Medical Device Park, DMIC Vikram Udyogpuri, Narwar, Ujjain, Madhya Pradesh 456664",
} as const;
