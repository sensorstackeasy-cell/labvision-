export type Item = { t: string; d: string };
export type Page = { title: string; lead: string; items?: Item[]; form?: "contact" | "quotation" | "service" | "document" | "distributor" | "demo"; faq?: boolean };

export const roles = [
  "Embedded Firmware Engineer", "Hardware and PCB Design Engineer", "Mechanical Design Engineer",
  "Regulatory and Quality Executive", "Sales and Service Engineer", "Engineering Intern",
];

export const pages: Record<string, Page> = {
  about: {
    title: "About us", lead: "Labvision MedTech designs and manufactures medical devices and biomedical waste treatment systems in India.",
    items: [
      { t: "Clinical first", d: "Every feature is judged by what it changes for a patient or a nurse." },
      { t: "Quality by design", d: "Requirements, risks and test results are written down and traceable, not reconstructed at the end." },
      { t: "Honest claims", d: "We publish what a device does and does not do, and mark anything still awaiting approval." },
      { t: "Support after delivery", d: "Installation, training and service are part of the product, not an afterthought." },
    ],
  },
  service: {
    title: "Service and support", lead: "A medical device is only as dependable as the support behind it.", form: "service",
    items: [
      { t: "Installation and commissioning", d: "Setup, testing and handover at your site, with a checklist you can keep on file." },
      { t: "Training", d: "Hands-on sessions for clinical and biomedical engineering staff, covering operation, alarms and cleaning." },
      { t: "Maintenance and calibration", d: "Scheduled preventive maintenance and calibration, with a record for every visit." },
      { t: "Spare parts and repair", d: "Genuine spares and repair for every product line, quoted against the device serial number." },
      { t: "Remote support", d: "For devices that support telemetry, our engineers can review logs and guide your team remotely." },
      { t: "Warranty and complaints", d: "Warranty terms are stated in each quotation. To report a problem, write to us with the device name and serial number." },
    ],
  },
  faq: {
    title: "Frequently asked questions", lead: "Quick answers for buyers, hospitals and partners.", faq: true,
    items: [
      { t: "Can I buy your products now?", d: "Our products are shown for information and are not available for sale until the required regulatory approvals are granted. Contact us for the current status." },
      { t: "How do I get a quotation?", d: "Use the Request quotation button, or write to sales@labvision.co.in with the product, quantity and delivery city." },
      { t: "Which standards are the devices designed to?", d: "Each product page lists the standards it is designed against, such as IEC 60601-1, and the Bio-Medical Waste Management Rules, 2016 for the incinerator. Ask us for certificate copies as they become available." },
      { t: "Can the devices connect to our hospital systems?", d: "Connectivity options are on each product page. Integration needs are confirmed during quotation." },
      { t: "Does an incinerator need government permission?", d: "Yes. Operating a biomedical waste incinerator needs authorization from the State Pollution Control Board. Our team can explain the technical details that application usually needs." },
      { t: "What training and service do you provide?", d: "Installation, training, maintenance, calibration and spares. See the Service and support page." },
      { t: "Do you work with distributors?", d: "We welcome enquiries from distributors and dealers. Use the Distributors page." },
      { t: "How is my information used?", d: "Only to reply to your enquiry or consider your application. See the privacy policy." },
    ],
  },
  distributors: { title: "Become a Labvision MedTech partner", lead: "We welcome enquiries from distributors and dealers who serve hospitals, clinics and diagnostic centres.", form: "distributor",
    items: [{ t: "Product range", d: "Four device lines that you can offer together or separately." }, { t: "Technical training", d: "Product and service training for your sales and support staff." },
      { t: "Sales material", d: "Datasheets and catalogs for each product." }, { t: "Direct access", d: "A direct line to our engineering and service team. Terms are discussed individually; territories depend on availability and regulatory approval." }] },
  demo: { title: "Request a demo or site visit", lead: "See a product, or have an engineer visit your department. Tell us the product and a preferred date.", form: "demo" },
  tenders: { title: "Tenders and GeM", lead: "If you buy through a hospital tender or the Government e-Marketplace (GeM), send us the tender document and we will respond with technical details.",
    items: [{ t: "What we can provide", d: "Product datasheets, technical specifications, the standards each device is designed against, and the certificates and licences that have been issued so far." },
      { t: "Regulatory status", d: "Our clinical devices are not available for sale until regulatory approval is granted. We will tell you the exact status before you commit to any tender." },
      { t: "How to start", d: "Use the quotation form or write to sales@labvision.co.in with the tender number, the product and the closing date." }], form: "quotation" },
  leadership: { title: "Leadership", lead: "The team accountable for how Labvision MedTech designs, builds and supports its devices." },
  contact: { title: "Visit, call or write to us", lead: "Our team is based at the DMIC Medical Device Park in Ujjain.", form: "contact" },
  quotation: { title: "Request a quotation", lead: "We reply with pricing, lead time and a datasheet. Products are not for sale until regulatory approval is granted.", form: "quotation" },
  privacy: {
    title: "Privacy policy", lead: "Last updated: October 2026. This is a working draft: have it reviewed by a lawyer before you rely on it.",
    items: [
      { t: "Who we are", d: "This website is run by Labvision MedTech (Plot No. 82, Medical Device Park, DMIC Vikram Udyogpuri, Narwar, Ujjain, Madhya Pradesh 456664, India). Questions about this policy can be sent to sales@labvision.co.in or +91 91799 84083." },
      { t: "What we collect", d: "Only what you type into our forms: name, organisation, email, phone, city, qualification, a link, your message and, for applications, your CV." },
      { t: "How your details reach us", d: "When you press send, your details travel over a secure connection to our server, are stored in our database and are emailed to our team. You receive a reference number you can use on the Track a request page." },
      { t: "How we use them", d: "To reply to enquiries, prepare quotations and consider job applications. We do not sell them. We share them only with staff and advisers who need them for these purposes. CVs are kept in private, encrypted storage that only authorised staff can open, and each access is logged." },
      { t: "How long we keep them", d: "Only as long as needed for the purpose they were given, then we delete them." },
      { t: "Your rights", d: "You can ask us to show, correct or delete your details at any time, as provided by applicable Indian law, including the Digital Personal Data Protection Act, 2023. Write to sales@labvision.co.in." },
      { t: "Analytics", d: "If analytics is switched on, we ask for your consent before counting visits with Google Analytics, which sets cookies. If you decline, the site works the same." },
      { t: "Cookies and third parties", d: "Visitors get no tracking cookies unless they accept analytics. Staff who log in get one essential session cookie. Maps links open Google Maps and the WhatsApp button opens WhatsApp, which have their own privacy terms." },
    ],
  },
};

export const needs = [
  { t: "ICU and emergency care", d: "Ventilation and continuous vital-sign monitoring for intensive care units, emergency rooms and wards.", p: ["ventilator", "patient-monitor"] },
  { t: "Transport and home care", d: "Compact, battery-backed devices that travel with the patient: ambulances, inter-hospital transfers and home care.", p: ["ventilator", "patient-monitor"] },
  { t: "Diabetes management", d: "Glucose readings every five minutes without finger pricks, viewed on a smartphone app.", p: ["cgm"] },
  { t: "Hospital waste management", d: "On-site treatment of infectious and pathological waste, designed to the Bio-Medical Waste Management Rules, 2016.", p: ["incinerator"] },
];
export const chips = ["ISO 13485 quality system", "IEC 60601-1 design basis, clinical devices", "CDSCO MDR 2017 pathway, clinical devices", "CPCB and BMW Rules 2016, incinerator", "Made in India"];
export const principles = [
  { t: "Design controls", d: "Requirements trace to verification tests, so each claim on a datasheet maps to a recorded result." },
  { t: "Risk management", d: "Hazards are analysed to ISO 14971 and re-reviewed after every field report." },
  { t: "Electrical safety and EMC", d: "Designed to IEC 60601-1 and the 60601-1-2 collateral standard, with pre-compliance checks in-house." },
  { t: "Software lifecycle", d: "Firmware follows IEC 62304 practices with versioned, signed OTA updates." },
  { t: "Regulatory route", d: "The ventilator, monitor and CGM are planned for registration under India's Medical Device Rules, 2017 through CDSCO." },
  { t: "Waste treatment route", d: "The incinerator follows the Bio-Medical Waste Management Rules, 2016 and CPCB emission and operating guidelines, with authorization from the State Pollution Control Board." },
];
export const leaders = {
  top: [{ a: "AR", t: "Founder and CEO", n: "Mr. Ankesh Rathi", d: "Leads the company vision, strategy and partnerships." }, { a: "DR", t: "Co-Founder and Managing Director", n: "Mrs. Diti Rathi", d: "Oversees management and day-to-day performance of the company." }],
  officers: [{ a: "CTO", t: "Chief Technology Officer", n: "Er. Kapil Malviya", d: "Leads R&D and Quality across firmware, hardware and software for every device line." },
    { a: "CFO", t: "Chief Financial Officer", n: "CA Ankta Gupta", d: "Oversees finance, funding, budgeting and investor relations." },
    { a: "COO", t: "Chief Operating Officer", n: "Dr. Priyanka Jhawar", d: "Runs manufacturing, supply chain, installation and after-sales service." },
    { a: "CHO", t: "Chief Human Resources Officer", n: "", d: "Leads hiring, training and team culture." }, { a: "CMO", t: "Chief Marketing Officer", n: "", d: "Leads brand, hospital and distributor outreach and market development." }],
};
