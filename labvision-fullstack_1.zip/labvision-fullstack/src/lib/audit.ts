import { sql, j } from "./db";

export async function audit(userId: string | null, action: string, entity: string, entityId = "", detail: Record<string, unknown> = {}) {
  await sql`insert into audit_log (user_id, action, entity, entity_id, detail) values (${userId}, ${action}, ${entity}, ${entityId}, ${j(detail)})`;
}
