import { sql } from "./db";

export async function getSetting(key: string, fallback = ""): Promise<string> {
  const [r] = await sql<{ value: string }[]>`select value from settings where key = ${key}`;
  return r?.value ?? fallback;
}
export const comingSoon = async () => (await getSetting("coming_soon", "true")) === "true";
