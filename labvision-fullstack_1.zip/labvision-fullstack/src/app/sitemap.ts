import type { MetadataRoute } from "next";
import { pages } from "@/lib/content";
import { sql } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = (process.env.SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");
  const [ps, posts] = await Promise.all([sql<{ slug: string }[]>`select slug from products where published`, sql<{ slug: string }[]>`select slug from posts where published`]);
  const fixed = ["", "/catalog", "/quality", "/certificates", "/careers", "/planner", "/track", "/news", ...Object.keys(pages).filter((s) => s !== "privacy").map((s) => `/${s}`), "/privacy"];
  return [...fixed, ...ps.map((p) => `/products/${p.slug}`), ...posts.map((p) => `/news/${p.slug}`)].map((u) => ({ url: base + u }));
}
