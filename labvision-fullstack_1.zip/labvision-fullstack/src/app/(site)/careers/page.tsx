import type { Metadata } from "next";
import Link from "next/link";
import CareerForm from "@/components/CareerForm";
import { roles } from "@/lib/content";

export const metadata: Metadata = { title: "Careers", description: "Build your career with Labvision MedTech." };
const WHY = [
  { t: "Real products", d: "Ventilators, monitors, glucose sensors and waste treatment systems, from first schematic to field service." },
  { t: "Engineering with discipline", d: "You work under a quality system built on ISO 13485 and IEC 60601-1 practices, and learn how regulated products are made." },
  { t: "Ownership", d: "A focused team means you own a subsystem early, from firmware to enclosure to documentation." },
];

export default async function Careers({ searchParams }: { searchParams: Promise<{ role?: string }> }) {
  const { role } = await searchParams;
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>Build your career with Labvision MedTech.</h1>
      <p className="lead">We make devices that clinicians and patients rely on. If you want your work to show up in a hospital ward, we would like to hear from you.</p>
      <div className="grid" style={{ marginBottom: 24 }}>{WHY.map((w) => <div className="card" key={w.t}><h3>{w.t}</h3><p>{w.d}</p></div>)}</div>
      <div className="two" style={{ alignItems: "start" }}>
        <div><h2 style={{ fontSize: 28 }}>Open positions</h2>
          {roles.map((r) => <div className="card" key={r} style={{ marginBottom: 10 }}><h3>{r}</h3><Link className="btn ghost" href={`/careers?role=${encodeURIComponent(r)}#apply`}>Apply for this role</Link></div>)}</div>
        <div id="apply"><h2 style={{ fontSize: 28 }}>Apply now</h2><CareerForm roles={roles} defaultRole={role && roles.includes(role) ? role : ""} /></div>
      </div>
    </div></section>
  );
}
