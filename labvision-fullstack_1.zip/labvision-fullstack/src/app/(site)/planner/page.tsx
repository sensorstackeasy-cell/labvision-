import type { Metadata } from "next";
import Planner from "@/components/Planner";

export const metadata: Metadata = { title: "Planning guide", description: "A quick starting estimate of monitors and ventilators for a department." };

export default function PlannerPage() {
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>Planning guide</h1>
      <p className="lead">Enter the number of beds in a department for a starting estimate of patient monitors and portable ventilators to discuss with us.</p>
      <Planner />
    </div></section>
  );
}
