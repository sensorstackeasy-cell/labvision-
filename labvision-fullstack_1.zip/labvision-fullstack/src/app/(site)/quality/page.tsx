import type { Metadata } from "next";
import { sql } from "@/lib/db";
import { principles } from "@/lib/content";

export const metadata: Metadata = { title: "Quality and compliance", description: "How Labvision MedTech designs, documents and tests its devices, and the honest status of each standard and licence." };
export const dynamic = "force-dynamic";
const LABEL: Record<string, string> = { in_process: "In process", design_basis: "Design basis", issued: "Issued" };

export default async function Quality() {
  const [rows, certs] = await Promise.all([
    sql<{ id: string; standard: string; scope: string; status: string; note: string }[]>`select id, standard, scope, status, note from compliance_status order by position`,
    sql<{ id: string; name: string; scope: string; status: string }[]>`select id, name, scope, status from certificates where published order by created_at`,
  ]);
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>Built under a quality system, not audited into one.</h1>
      <p className="lead">Every device carries a design history file, a risk file and a traceable bill of materials.</p>
      <div className="grid">{principles.map((i) => <div className="card" key={i.t}><h3>{i.t}</h3><p>{i.d}</p></div>)}</div>
      <h2 style={{ marginTop: 36 }}>Compliance status</h2>
      <table><thead><tr><th>Standard</th><th>Applies to</th><th>Status</th><th>Note</th></tr></thead><tbody>
        {rows.map((r) => <tr key={r.id}><td>{r.standard}</td><td>{r.scope}</td><td><span className={`badge ${r.status}`}>{LABEL[r.status]}</span></td><td>{r.note}</td></tr>)}</tbody></table>
      <h2 style={{ marginTop: 36 }}>Certificates and licences</h2>
      <table><thead><tr><th>Document</th><th>Scope</th><th>Status</th></tr></thead><tbody>
        {certs.map((c) => <tr key={c.id}><td>{c.name}</td><td>{c.scope}</td><td><span className={`badge ${c.status}`}>{LABEL[c.status]}</span></td></tr>)}</tbody></table>
      <p className="note">Status is shown honestly. We update this table when a registration or certificate is granted.</p>
    </div></section>
  );
}
