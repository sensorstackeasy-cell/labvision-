import type { Metadata } from "next";
import Link from "next/link";
import { sql } from "@/lib/db";
import EnquiryForm from "@/components/EnquiryForm";

export const metadata: Metadata = { title: "Certificates and documents" };
export const dynamic = "force-dynamic";
type C = { id: string; name: string; description: string; scope: string; number: string; valid_until: Date | null; url: string; status: string };
const KINDS = [
  { t: "Quality system", d: "Quality manual summary and design control procedures, aligned to ISO 13485." },
  { t: "Test reports", d: "Electrical safety and EMC reports for clinical devices, to IEC 60601-1 and 60601-1-2, where issued." },
  { t: "Regulatory status", d: "Current CDSCO registration status for the ventilator, monitor and CGM." },
  { t: "Pollution control", d: "CPCB and State Pollution Control Board documents relevant to the incinerator." },
];

export default async function Certificates() {
  const certs = await sql<C[]>`select id, name, description, scope, number, valid_until, url, status from certificates where published order by created_at`;
  const names = (await sql<{ name: string }[]>`select name from products where published order by position`).map((r) => r.name);
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>Certificates and documents</h1>
      <p className="lead">Hospitals, distributors and regulators can ask for our documents at any time. We share only documents that have been issued. See the <Link href="/quality">quality and compliance status</Link>.</p>
      <div className="grid">{certs.map((c) => (
        <div className="card" key={c.id}><h3>{c.name}</h3><p>{c.scope || c.description}</p>
          <p><span className={`badge ${c.status}`}>{c.status === "issued" ? "Issued" : "In process"}</span> {[c.number, c.valid_until && `Valid until ${c.valid_until.toISOString().slice(0, 10)}`].filter(Boolean).join(" | ")}</p>
          {c.status === "issued" && c.url && <a className="btn ghost" href={c.url} target="_blank" rel="noopener noreferrer">View document</a>}</div>))}</div>
      <h2 style={{ marginTop: 32 }}>Request documents</h2>
      <div className="grid">{KINDS.map((k) => <div className="card" key={k.t}><h3>{k.t}</h3><p>{k.d}</p></div>)}</div>
      <div style={{ maxWidth: 640, marginTop: 20 }}><EnquiryForm kind="document" products={names} defaultProduct="Certificates and documents" /></div>
    </div></section>
  );
}
