import Image from "next/image";
import Link from "next/link";
import type { CSSProperties } from "react";
import WelcomeGate from "@/components/WelcomeGate";
import { sql } from "@/lib/db";
import { chips, needs } from "@/lib/content";
import { comingSoon } from "@/lib/settings";

export const dynamic = "force-dynamic";
type P = { slug: string; name: string; tagline: string; accent: string; status: string; hero_image: string };

export default async function Home() {
  const [products, soon] = await Promise.all([sql<P[]>`select slug, name, tagline, accent, status, hero_image from products where published order by position`, comingSoon()]);
  const byslug = Object.fromEntries(products.map((p) => [p.slug, p]));
  return (
    <>
      <WelcomeGate soon={soon} tiles={products.map((p) => ({ slug: p.slug, name: p.name, img: p.hero_image, accent: p.accent }))} />
      <section className="s"><div className="wrap">
        {soon && <i className="soon big">Coming soon</i>}
        <h1>Medical devices engineered for the moment someone depends on them.</h1>
        <p className="lead">Labvision designs and manufactures four connected device lines for critical care, continuous monitoring, diabetes management and biomedical waste treatment, built under a quality system from the first schematic.</p>
        <Link className="btn" href="/quotation">Request quotation</Link> <Link className="btn ghost" href="/demo">Request a demo</Link> <Link className="btn ghost" href="/catalog">Catalog and downloads</Link>
        <div className="chips">{chips.map((c) => <span key={c}>{c}</span>)}</div>
      </div></section>
      <section className="s" id="need"><div className="wrap">
        <h2>Find the right device for your department.</h2><p>Start from the clinical need. Each card links to the products that address it.</p>
        <div className="grid">{needs.map((n) => (<div className="card" key={n.t}><h3>{n.t}</h3><p>{n.d}</p>
          <p className="row">{n.p.filter((s) => byslug[s]).map((s) => <Link key={s} className="pill" href={`/products/${s}`}>{byslug[s].name}</Link>)}</p></div>))}</div>
      </div></section>
      <section className="s" id="products"><div className="wrap">
        <h2>Our products</h2>
        <div className="grid">{products.map((p) => (
          <Link key={p.slug} href={`/products/${p.slug}`} className="card" style={{ "--c": p.accent, textDecoration: "none" } as CSSProperties}>
            <Image src={p.hero_image} alt="" width={500} height={340} />
            {p.status === "coming_soon" && <span className="soon" style={{ marginTop: 10 }}>Coming soon</span>}
            <h3>{p.name}</h3><p>{p.tagline}</p></Link>))}</div>
      </div></section>
    </>
  );
}
