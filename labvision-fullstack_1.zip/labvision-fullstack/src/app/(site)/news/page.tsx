import type { Metadata } from "next";
import Link from "next/link";
import { sql } from "@/lib/db";

export const metadata: Metadata = { title: "News" };
export const dynamic = "force-dynamic";

export default async function News() {
  const posts = await sql<{ slug: string; title: string; summary: string; published_at: Date }[]>`select slug, title, summary, published_at from posts where published order by published_at desc limit 50`;
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>News</h1>
      {posts.length === 0 && <p>No news yet.</p>}
      <div className="grid">{posts.map((p) => <Link key={p.slug} href={`/news/${p.slug}`} className="card" style={{ textDecoration: "none" }}><p className="note">{p.published_at.toISOString().slice(0, 10)}</p><h3>{p.title}</h3><p>{p.summary}</p></Link>)}</div>
    </div></section>
  );
}
