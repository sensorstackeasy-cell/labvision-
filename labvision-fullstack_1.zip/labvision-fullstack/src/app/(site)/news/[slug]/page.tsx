import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { sql } from "@/lib/db";

export const dynamic = "force-dynamic";
type Post = { title: string; summary: string; body: string; published_at: Date };
const load = async (slug: string) => (await sql<Post[]>`select title, summary, body, published_at from posts where slug = ${slug} and published`)[0];

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = await load((await params).slug);
  return p ? { title: p.title, description: p.summary } : {};
}
export default async function Article({ params }: { params: Promise<{ slug: string }> }) {
  const p = await load((await params).slug);
  if (!p) notFound();
  return (
    <section className="s"><div className="wrap" style={{ maxWidth: 760 }}>
      <p className="note">{p.published_at.toISOString().slice(0, 10)}</p>
      <h1 style={{ fontSize: "clamp(30px,4vw,46px)" }}>{p.title}</h1>
      {/* plain text only: paragraphs split on blank lines, no HTML is ever rendered from the CMS */}
      {p.body.split(/\n\s*\n/).map((t, i) => <p key={i} className={i === 0 ? "lead" : ""} style={{ whiteSpace: "pre-wrap" }}>{t}</p>)}
    </div></section>
  );
}
