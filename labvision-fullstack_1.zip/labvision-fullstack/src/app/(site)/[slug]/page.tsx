import { notFound } from "next/navigation";
import type { Metadata } from "next";
import type { CSSProperties } from "react";
import { leaders, pages } from "@/lib/content";
import { sql } from "@/lib/db";
import { site } from "@/lib/site";
import EnquiryForm from "@/components/EnquiryForm";

export const dynamic = "force-dynamic";
export const dynamicParams = false;
export const generateStaticParams = () => Object.keys(pages).map((slug) => ({ slug }));

const MAPS = encodeURIComponent("Medical Device Park, DMIC Vikram Udyogpuri, Narwar, Ujjain, Madhya Pradesh 456664");

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = pages[(await params).slug];
  return p ? { title: p.title, description: p.lead } : {};
}

function Person({ a, t, n, d, c }: { a: string; t: string; n: string; d: string; c: string }) {
  return <div className="card person" style={{ "--c": c } as CSSProperties}><div className="av" aria-hidden="true">{a}</div><div><b>{t}</b><b style={{ fontSize: 15 }}>{n}</b><p>{d}</p></div></div>;
}

export default async function Page({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ product?: string }> }) {
  const slug = (await params).slug, page = pages[slug];
  if (!page) notFound();
  const { product } = await searchParams;
  const names = page.form ? (await sql<{ name: string }[]>`select name from products where published order by position`).map((r) => r.name) : [];
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>{page.title}</h1>
      <p className="lead">{page.lead}</p>
      {slug === "leadership" && <>
        <div className="lg">{leaders.top.map((l) => <Person key={l.n} {...l} c="#0c2a33" />)}</div>
        <div className="lg" style={{ marginTop: 14 }}>{leaders.officers.filter((o) => o.n).map((l) => <Person key={l.a} {...l} c="#1b8a8f" />)}</div></>}
      {slug === "contact" && <div className="grid" style={{ marginBottom: 24 }}>
        <div className="card"><h3>Address</h3><p>{site.address}, India</p><a className="btn ghost" href={`https://www.google.com/maps/search/?api=1&query=${MAPS}`} target="_blank" rel="noopener noreferrer">Open in Google Maps</a>{" "}
          <a className="btn ghost" href={`https://www.google.com/maps/dir/?api=1&destination=${MAPS}`} target="_blank" rel="noopener noreferrer">Get directions</a>
          <p className="note" style={{ marginTop: 10 }}>The map opens the Medical Device Park. Our unit is Plot No. 82 inside the park.</p></div>
        <div className="card"><h3>Hours</h3><p>Monday to Saturday, 10:00 to 18:00 IST.</p><h3>Response time</h3><p>We reply to every enquiry within one working day.</p></div>
        <div className="card"><h3>Phone and WhatsApp</h3><p><a href={`tel:${site.tel}`}>{site.phone}</a></p><p><a href={`mailto:${site.email}`}>{site.email}</a></p></div></div>}
      {page.faq ? page.items?.map((i) => <details key={i.t}><summary>{i.t}</summary><p>{i.d}</p></details>)
        : page.items && <div className="grid">{page.items.map((i) => <div className="card" key={i.t}><h3>{i.t}</h3><p>{i.d}</p></div>)}</div>}
      {slug === "service" && <p style={{ marginTop: 16 }}><a className="btn" href="/quotation?product=Service%20or%20spare%20parts">Request service or spares</a></p>}
      {page.form && <div style={{ maxWidth: 640, marginTop: 24 }}><EnquiryForm kind={page.form} products={names} defaultProduct={product ?? ""} /></div>}
    </div></section>
  );
}
