import Image from "next/image";
import Link from "next/link";
import type { CSSProperties } from "react";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { sql } from "@/lib/db";
import ProductTabs from "@/components/ProductTabs";
import Signal from "@/components/Signal";
import VideoButton from "@/components/VideoButton";
import ZoomImage from "@/components/ZoomImage";

export const dynamic = "force-dynamic";

type Product = {
  slug: string; name: string; tagline: string; accent: string; status: string; overview: string[]; how_it_works: { t: string; d: string }[];
  specs: [string, string][]; standards: string[]; stats: [string, string][]; hero_image: string; exploded_image: string; catalog_pdf: string;
  related: string[]; signal: "vent" | "ecg" | "cgm" | "inc" | "none"; video_url: string;
};
const load = async (slug: string) => (await sql<Product[]>`select * from products where slug = ${slug} and published`)[0];

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = await load((await params).slug);
  return p ? { title: p.name, description: p.tagline } : {};
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await load((await params).slug);
  if (!p) notFound();
  const rel = p.related.length ? await sql<{ slug: string; name: string }[]>`select slug, name from products where slug = any(${p.related}) and published` : [];
  return (
    <div className="wrap" style={{ "--a": p.accent } as CSSProperties}>
      <section className="s">
        <div className="two" style={{ alignItems: "start" }}>
          <div>
            {p.status === "coming_soon" && <span className="soon">Coming soon</span>}
            <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>{p.name}</h1>
            <p className="lead" style={{ margin: 0 }}>{p.tagline}</p>
            <ProductTabs name={p.name} overview={p.overview} how={p.how_it_works} specs={p.specs} standards={p.standards} exploded={p.exploded_image} />
            <div className="row" style={{ marginTop: 20 }}>
              <Link className="btn" href={`/quotation?product=${encodeURIComponent(p.name)}`}>Request quotation</Link>
              <a className="btn ghost" href={p.catalog_pdf} download>Download datasheet (PDF)</a>
              <Link className="btn ghost" href={`/demo?product=${encodeURIComponent(p.name)}`}>Request a demo</Link>
              {p.video_url && <VideoButton url={p.video_url} title={p.name} />}
            </div>
            {rel.length > 0 && <p className="note" style={{ marginTop: 16 }}>Related: {rel.map((r, i) => <span key={r.slug}>{i > 0 && " · "}<Link href={`/products/${r.slug}`}>{r.name}</Link></span>)}</p>}
          </div>
          <div className="viz">
            <ZoomImage src={p.hero_image} alt={`${p.name} product image`} w={900} h={620} />
            {p.signal !== "none" && <div style={{ marginTop: 12 }}><Signal kind={p.signal} color={p.accent} /></div>}
            <div className="stats">{p.stats.map(([v, l]) => <div key={l}><b>{v}</b><span>{l}</span></div>)}</div>
            <p className="note">Product image and signal are illustrative, not patient data.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
