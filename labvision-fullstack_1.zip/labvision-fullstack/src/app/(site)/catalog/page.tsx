import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import type { CSSProperties } from "react";
import { statSync } from "node:fs";
import { join } from "node:path";
import { sql } from "@/lib/db";

export const metadata: Metadata = { title: "Catalog and downloads", description: "Download a PDF datasheet for any product, or the complete catalog." };
export const dynamic = "force-dynamic";
const mb = (f: string) => { try { return (statSync(join(process.cwd(), "public", f)).size / 1048576).toFixed(1) + " MB"; } catch { return ""; } };

export default async function Catalog() {
  const ps = await sql<{ slug: string; name: string; tagline: string; accent: string; hero_image: string; catalog_pdf: string }[]>`select slug, name, tagline, accent, hero_image, catalog_pdf from products where published order by position`;
  const all = "/catalog/Labvision-Complete-Catalog.pdf";
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>Product catalog</h1>
      <p className="lead">Download a PDF datasheet for any product, or the complete catalog with all four. Each one includes specifications, how the device works and an exploded view.</p>
      <div className="grid">
        <div className="card" style={{ "--c": "#0c2a33" } as CSSProperties}><h3>Complete catalog</h3><p>All four products. PDF {mb(all)}</p>
          <div className="row"><a className="btn" href={all} download>Download PDF</a><Link className="btn ghost" href="/quotation">Request quotation</Link></div></div>
        {ps.map((p) => (<div className="card" key={p.slug} style={{ "--c": p.accent } as CSSProperties}>
          <Image src={p.hero_image} alt="" width={400} height={270} /><h3>{p.name}</h3><p>{p.tagline} PDF {mb(p.catalog_pdf)}</p>
          <div className="row"><a className="btn" href={p.catalog_pdf} download>Download PDF</a><Link className="btn ghost" href={`/quotation?product=${encodeURIComponent(p.name)}`}>Request quotation</Link></div></div>))}
      </div>
    </div></section>
  );
}
