import type { Metadata } from "next";
import TrackForm from "@/components/TrackForm";

export const metadata: Metadata = { title: "Track a request" };

export default function Track() {
  return (
    <section className="s"><div className="wrap">
      <h1 style={{ fontSize: "clamp(32px,4.5vw,52px)" }}>Track a request</h1>
      <p className="lead">Enter the reference number you received after sending a request or application, with the same email address.</p>
      <TrackForm />
    </div></section>
  );
}
