import Link from "next/link";
import type { ReactNode } from "react";
import Drawer from "@/components/Drawer";
import Consent from "@/components/Consent";
import { sql } from "@/lib/db";
import { site } from "@/lib/site";
import { buildNav } from "@/lib/nav";
import { comingSoon } from "@/lib/settings";

export const dynamic = "force-dynamic";

const orgJsonLd = {
  "@context": "https://schema.org", "@type": "Organization", name: site.name, telephone: site.tel, email: site.email,
  address: { "@type": "PostalAddress", streetAddress: "Plot No. 82, Medical Device Park, DMIC Vikram Udyogpuri, Narwar", addressLocality: "Ujjain", addressRegion: "Madhya Pradesh", postalCode: "456664", addressCountry: "IN" },
};

export default async function SiteLayout({ children }: { children: ReactNode }) {
  const [products, [{ n }], soon] = await Promise.all([
    sql<{ slug: string; name: string; accent: string }[]>`select slug, name, accent from products where published order by position`,
    sql<{ n: number }[]>`select count(*)::int as n from posts where published`,
    comingSoon(),
  ]);
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd).replace(/</g, "\\u003c") }} />
      <header className="top"><div className="wrap">
        <Drawer items={buildNav(products, n > 0)} phone={site.phone} tel={site.tel} email={site.email} />
        <Link className="logo" href="/">{site.name}</Link>{soon && <span className="soon">Coming soon</span>}
        <a href={`tel:${site.tel}`} style={{ marginLeft: "auto", fontWeight: 600, textDecoration: "none" }}>{site.phone}</a>
        <Link className="btn" href="/quotation">Request quotation</Link>
      </div></header>
      <main>{children}</main>
      <footer><div className="wrap">
        <p>&copy; 2026 {site.name}. {site.address}. <a href={`tel:${site.tel}`}>{site.phone}</a> | <a href={`mailto:${site.email}`}>{site.email}</a></p>
        <p>Products are shown for information and are not available for sale until regulatory approval is granted. Specifications are indicative and product images are representative. <Link href="/privacy">Privacy policy</Link></p>
      </div></footer>
      <a className="fab" href={`https://wa.me/${site.whatsapp}?text=${encodeURIComponent("Hello Labvision MedTech, I would like to know more.")}`} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">WhatsApp</a>
      <Consent />
    </>
  );
}
