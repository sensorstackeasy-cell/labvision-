import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.SITE_URL ?? "http://localhost:3000"),
  title: { default: "Labvision MedTech | Medical Devices", template: "%s | Labvision MedTech" },
  description: "Portable ventilator, patient monitor, CGM system and biomedical waste incinerator, designed and made in India.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
