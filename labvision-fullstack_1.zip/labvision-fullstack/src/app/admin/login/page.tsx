import { loginAction } from "../actions";

export const metadata = { title: "Staff login", robots: { index: false } };

export default async function Login({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return (
    <div className="wrap" style={{ maxWidth: 420, paddingTop: 80 }}>
      <h1 style={{ fontSize: 36 }}>Staff login</h1>
      <form className="card" action={loginAction}>
        <label htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="username" required />
        <label htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete="current-password" required />
        <button className="btn">Sign in</button>
        {error && <p role="alert" className="err">{error === "rate" ? "Too many attempts. Try again later." : "Incorrect email or password, or the account is temporarily locked."}</p>}
      </form>
    </div>
  );
}
