import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { setComplianceStatus } from "../../actions";

const OPTS = [["in_process", "In process"], ["design_basis", "Design basis"], ["issued", "Issued"]];

export default async function Compliance() {
  await requireUser(["admin"]);
  const rows = await sql<{ id: string; standard: string; scope: string; status: string; note: string }[]>`select id, standard, scope, status, note from compliance_status order by position`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Compliance status</h1>
      <p>Shown on the public Quality page. Set a row to Issued only when the certificate or registration has really been granted.</p>
      {rows.map((r) => (
        <form key={r.id} action={setComplianceStatus} className="card" style={{ marginBottom: 12 }}><input type="hidden" name="id" value={r.id} />
          <b>{r.standard}</b> <small>({r.scope})</small>
          <div className="row" style={{ marginTop: 8 }}><select name="status" defaultValue={r.status} aria-label="Status">{OPTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
            <input name="note" defaultValue={r.note} maxLength={300} aria-label="Note" style={{ flex: 1, minWidth: 240 }} /><button className="btn ghost" style={{ marginTop: 0 }}>Save</button></div></form>))}
    </>
  );
}
