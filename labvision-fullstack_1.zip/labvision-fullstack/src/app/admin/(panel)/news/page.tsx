import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { deletePost, savePost } from "../../actions";

export default async function NewsAdmin() {
  await requireUser(["admin"]);
  const rows = await sql<{ id: string; slug: string; title: string; published: boolean }[]>`select id, slug, title, published from posts order by created_at desc`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>News</h1>
      <p>Plain text only. Separate paragraphs with a blank line. The News link appears in the site menu once one post is published. Saving a post with an existing slug updates it.</p>
      <table><thead><tr><th>Title</th><th>Slug</th><th>Published</th><th></th></tr></thead><tbody>
        {rows.map((p) => <tr key={p.id}><td>{p.title}</td><td>{p.slug}</td><td>{p.published ? "Yes" : "No"}</td><td><form action={deletePost}><input type="hidden" name="id" value={p.id} /><button className="btn ghost" style={{ marginTop: 0 }}>Delete</button></form></td></tr>)}</tbody></table>
      <form action={savePost} className="card" style={{ maxWidth: 640, marginTop: 24 }}>
        <label>Slug (lowercase letters, numbers, hyphens)<input name="slug" required pattern="[a-z0-9-]{3,80}" /></label><label>Title<input name="title" required maxLength={160} /></label>
        <label>Summary<input name="summary" maxLength={300} /></label><label>Body<textarea name="body" rows={10} required /></label>
        <label className="ck"><input type="checkbox" name="published" /> Publish</label><button className="btn">Save post</button></form>
    </>
  );
}
