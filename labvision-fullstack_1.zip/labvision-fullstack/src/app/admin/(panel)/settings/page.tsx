import { requireUser } from "@/lib/auth";
import { comingSoon } from "@/lib/settings";
import { saveSettings, sendTestEmail } from "../../actions";

export default async function Settings({ searchParams }: { searchParams: Promise<{ mail?: string }> }) {
  const { mail } = await searchParams;
  await requireUser(["admin"]);
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Site settings</h1>
      <form action={saveSettings} className="card" style={{ maxWidth: 520 }}>
        <label className="ck"><input type="checkbox" name="coming_soon" defaultChecked={await comingSoon()} /> Show the site-wide &ldquo;Coming soon&rdquo; label (top bar, home page, welcome page)</label>
        <p className="note">Each product also has its own Coming soon or Available status in Products.</p><button className="btn">Save</button>
      </form>
      <h2 style={{ fontSize: 24, marginTop: 32 }}>Email delivery</h2>
      <p>Enquiries and applications are emailed to <b>{process.env.MAIL_TO ?? "(MAIL_TO not set)"}</b>.</p>
      <form action={sendTestEmail}><button className="btn">Send a test email</button></form>
      {mail === "failed" && <p role="alert" className="err">The test email could not be sent. Check the email settings in the environment and the server log.</p>}
      {mail === "skipped" && <p role="alert" className="err">No email service is configured. Set SMTP_HOST and MAIL_TO, or WEB3FORMS_KEY.</p>}
      {(mail === "smtp" || mail === "web3forms") && <p role="status">Test email sent through {mail === "smtp" ? "SMTP" : "Web3Forms"}. Check the inbox (and the spam folder).</p>}
    </>
  );
}
