import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { addCertificate, deleteCertificate, setCertificateStatus } from "../../actions";

type C = { id: string; name: string; number: string; valid_until: Date | null; url: string; published: boolean; status: string };

export default async function Certificates() {
  await requireUser(["admin"]);
  const rows = await sql<C[]>`select id, name, number, valid_until, url, published, status from certificates order by created_at`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Certificates</h1>
      <p>Only add documents that have actually been issued. Published ones appear on the public Certificates page.</p>
      <table><thead><tr><th>Name</th><th>Number</th><th>Valid until</th><th>Published</th><th>Status, number and link</th><th></th></tr></thead><tbody>
        {rows.map((c) => <tr key={c.id}><td>{c.name}</td><td>{c.number}</td><td>{c.valid_until?.toISOString().slice(0, 10) ?? ""}</td><td>{c.published ? "Yes" : "No"}</td>
          <td><form action={setCertificateStatus} className="row"><input type="hidden" name="id" value={c.id} /><select name="status" defaultValue={c.status}><option value="in_process">In process</option><option value="issued">Issued</option></select><input name="number" defaultValue={c.number} placeholder="Number" /><input name="url" defaultValue={c.url} placeholder="https:// link" /><button className="btn ghost" style={{ marginTop: 0 }}>Save</button></form></td>
          <td><form action={deleteCertificate}><input type="hidden" name="id" value={c.id} /><button className="btn ghost" style={{ marginTop: 0 }}>Delete</button></form></td></tr>)}
      </tbody></table>
      <form action={addCertificate} className="card" style={{ maxWidth: 560, marginTop: 24 }}>
        <label>Name<input name="name" required maxLength={150} /></label><label>Description<input name="description" maxLength={400} /></label>
        <label>Certificate number<input name="number" maxLength={80} /></label><label>Valid until<input name="valid" type="date" /></label>
        <label>Link to the document (https://)<input name="url" type="url" maxLength={400} /></label>
        <label className="ck"><input type="checkbox" name="published" /> Publish on the site</label><button className="btn">Add certificate</button>
      </form>
    </>
  );
}
