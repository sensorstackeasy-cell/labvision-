import Link from "next/link";
import type { ReactNode } from "react";
import { requireUser } from "@/lib/auth";
import { logoutAction } from "../actions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin", robots: { index: false, follow: false } };

export default async function PanelLayout({ children }: { children: ReactNode }) {
  const u = await requireUser(); // every panel page is behind this check
  const links: [string, string, boolean][] = [["Enquiries", "/admin", true], ["Applications", "/admin/applications", false], ["Products", "/admin/products", false],
    ["Certificates", "/admin/certificates", false], ["Compliance", "/admin/compliance", false], ["News", "/admin/news", false], ["Settings", "/admin/settings", false], ["Users", "/admin/users", false], ["Audit log", "/admin/audit", false], ["Security", "/admin/security", true]];
  return (
    <div className="admin">
      <header className="top"><div className="wrap">
        <Link className="logo" href="/admin">Labvision admin</Link>
        <nav>{links.filter(([, , any]) => any || u.role === "admin").map(([l, h]) => <Link key={h} href={h}>{l}</Link>)}</nav>
        <span style={{ marginLeft: "auto", fontSize: 14 }}>{u.name} ({u.role})</span>
        <form action={logoutAction}><button className="btn ghost" style={{ marginTop: 0 }}>Sign out</button></form>
      </div></header>
      <div className="wrap" style={{ padding: "28px 20px" }}>{!u.totp_enabled && u.role === "admin" && <p role="note" className="card" style={{ marginBottom: 16 }}>Turn on two-step verification in <a href="/admin/security">Security</a> to protect this admin account.</p>}{children}</div>
    </div>
  );
}
