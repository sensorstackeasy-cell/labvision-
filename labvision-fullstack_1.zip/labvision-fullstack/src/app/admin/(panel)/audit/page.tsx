import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";

export default async function Audit() {
  await requireUser(["admin"]);
  const rows = await sql<{ id: string; at: Date; action: string; entity: string; entity_id: string; email: string | null }[]>`
    select a.id, a.at, a.action, a.entity, a.entity_id, u.email from audit_log a left join users u on u.id = a.user_id order by a.at desc limit 200`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Audit log</h1>
      <table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Target</th></tr></thead><tbody>
        {rows.map((r) => <tr key={r.id}><td>{r.at.toISOString().slice(0, 19).replace("T", " ")}</td><td>{r.email ?? "anonymous"}</td><td>{r.action}</td><td>{r.entity} {r.entity_id.slice(0, 8)}</td></tr>)}
      </tbody></table>
    </>
  );
}
