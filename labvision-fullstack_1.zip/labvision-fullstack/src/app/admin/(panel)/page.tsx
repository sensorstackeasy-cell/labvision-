import Link from "next/link";
import { sql } from "@/lib/db";
import { setEnquiryStatus } from "../actions";

type E = { id: string; ref: string; kind: string; name: string; email: string; product: string; status: string; created_at: Date };
const STATUSES = ["new", "in_progress", "quoted", "won", "closed"];

export default async function Enquiries({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const { status } = await searchParams;
  const filter = STATUSES.includes(status ?? "") ? status! : null;
  const rows = await sql<E[]>`select id, ref, kind, name, email, product, status, created_at from enquiries ${filter ? sql`where status = ${filter}` : sql``} order by created_at desc limit 200`;
  const counts = await sql<{ status: string; n: number }[]>`select status, count(*)::int as n from enquiries group by status`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Enquiries</h1>
      <p><a className="btn ghost" href="/admin/export">Export CSV (admins)</a></p>
      <p className="row">{["all", ...STATUSES].map((s) => <Link key={s} className="pill" href={s === "all" ? "/admin" : `/admin?status=${s}`}>{s} {s !== "all" && `(${counts.find((c) => c.status === s)?.n ?? 0})`}</Link>)}</p>
      <table><thead><tr><th>Ref</th><th>Date</th><th>Type</th><th>Name</th><th>Product</th><th>Status</th></tr></thead><tbody>
        {rows.map((r) => (<tr key={r.id}>
          <td><Link href={`/admin/enquiries/${r.id}`}>{r.ref}</Link></td><td>{r.created_at.toISOString().slice(0, 10)}</td><td>{r.kind}</td><td>{r.name}<br /><small>{r.email}</small></td><td>{r.product}</td>
          <td><form action={setEnquiryStatus} className="row"><input type="hidden" name="id" value={r.id} />
            <select name="status" defaultValue={r.status} aria-label="Status">{STATUSES.map((s) => <option key={s}>{s}</option>)}</select><button className="btn ghost" style={{ marginTop: 0 }}>Save</button></form></td>
        </tr>))}
      </tbody></table>
      {rows.length === 0 && <p>No enquiries yet.</p>}
    </>
  );
}
