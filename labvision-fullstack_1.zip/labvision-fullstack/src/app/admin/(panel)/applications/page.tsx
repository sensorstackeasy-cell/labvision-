import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { setApplicationStatus } from "../../actions";

type A = { id: string; role: string; name: string; email: string; phone: string; experience: string; city: string; link: string; cv_name: string | null; status: string; created_at: Date };
const STATUSES = ["new", "shortlisted", "interview", "offer", "rejected"];

export default async function Applications() {
  await requireUser(["admin"]); // personal data: admins only
  const rows = await sql<A[]>`select id, role, name, email, phone, experience, city, link, cv_name, status, created_at from applications order by created_at desc limit 200`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Applications</h1>
      <table><thead><tr><th>Date</th><th>Role</th><th>Candidate</th><th>Experience</th><th>CV</th><th>Status</th></tr></thead><tbody>
        {rows.map((r) => (<tr key={r.id}>
          <td>{r.created_at.toISOString().slice(0, 10)}</td><td>{r.role}</td><td>{r.name}<br /><small>{r.email} | {r.phone} | {r.city}</small>{r.link && <><br /><a href={r.link} rel="noopener noreferrer nofollow" target="_blank">Profile</a></>}</td>
          <td>{r.experience}</td><td>{r.cv_name ? <a href={`/admin/applications/${r.id}/cv`}>Download</a> : "None"}</td>
          <td><form action={setApplicationStatus} className="row"><input type="hidden" name="id" value={r.id} />
            <select name="status" defaultValue={r.status} aria-label="Status">{STATUSES.map((s) => <option key={s}>{s}</option>)}</select><button className="btn ghost" style={{ marginTop: 0 }}>Save</button></form></td>
        </tr>))}
      </tbody></table>
      {rows.length === 0 && <p>No applications yet.</p>}
    </>
  );
}
