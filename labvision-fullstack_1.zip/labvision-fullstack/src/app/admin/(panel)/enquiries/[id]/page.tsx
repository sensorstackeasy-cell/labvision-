import { notFound } from "next/navigation";
import { sql } from "@/lib/db";
import { addNote } from "../../../actions";

type E = { id: string; ref: string; kind: string; name: string; email: string; phone: string; organisation: string; product: string; message: string; details: Record<string, string>; status: string; created_at: Date };

export default async function Detail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const [e] = await sql<E[]>`select * from enquiries where id = ${id}`;
  if (!e) notFound();
  const notes = await sql<{ id: string; body: string; created_at: Date; name: string }[]>`select n.id, n.body, n.created_at, u.name from enquiry_notes n join users u on u.id = n.user_id where n.enquiry_id = ${id} order by n.created_at`;
  return (
    <>
      <h1 style={{ fontSize: 30 }}>{e.ref}: {e.kind}</h1>
      <table><tbody>
        {([["Name", e.name], ["Organisation", e.organisation], ["Email", e.email], ["Phone", e.phone], ["Product", e.product], ["Status", e.status], ["Received", e.created_at.toISOString()], ...Object.entries(e.details)] as [string, string][])
          .map(([k, v]) => <tr key={k}><th scope="row">{k}</th><td>{v}</td></tr>)}
      </tbody></table>
      <h2 style={{ fontSize: 22, marginTop: 24 }}>Message</h2><p style={{ whiteSpace: "pre-wrap" }}>{e.message}</p>
      <h2 style={{ fontSize: 22 }}>Notes</h2>
      {notes.map((n) => <p key={n.id}><b>{n.name}</b> ({n.created_at.toISOString().slice(0, 16).replace("T", " ")}): {n.body}</p>)}
      <form action={addNote} className="card" style={{ maxWidth: 560 }}><input type="hidden" name="id" value={e.id} />
        <label htmlFor="body">Add a note</label><textarea id="body" name="body" rows={3} required maxLength={2000} /><button className="btn">Save note</button></form>
    </>
  );
}
