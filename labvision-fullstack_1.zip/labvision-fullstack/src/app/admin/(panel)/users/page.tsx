import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { createUser, setUserActive } from "../../actions";

type U = { id: string; name: string; email: string; role: string; active: boolean };

export default async function Users() {
  const me = await requireUser(["admin"]);
  const rows = await sql<U[]>`select id, name, email, role, active from users order by created_at`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Staff users</h1>
      <p>Admin: everything. Sales: enquiries only.</p>
      <table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th><th></th></tr></thead><tbody>
        {rows.map((u) => <tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.active ? "Yes" : "No"}</td>
          <td>{u.id !== me.id && <form action={setUserActive}><input type="hidden" name="id" value={u.id} /><input type="hidden" name="active" value={String(!u.active)} /><button className="btn ghost" style={{ marginTop: 0 }}>{u.active ? "Disable" : "Enable"}</button></form>}</td></tr>)}
      </tbody></table>
      <form action={createUser} className="card" style={{ maxWidth: 480, marginTop: 24 }}>
        <label>Name<input name="name" required /></label><label>Email<input name="email" type="email" required /></label>
        <label>Role<select name="role"><option value="sales">sales</option><option value="admin">admin</option></select></label>
        <label>Temporary password (12+ characters)<input name="password" type="password" minLength={12} required autoComplete="new-password" /></label>
        <button className="btn">Create user</button>
      </form>
    </>
  );
}
