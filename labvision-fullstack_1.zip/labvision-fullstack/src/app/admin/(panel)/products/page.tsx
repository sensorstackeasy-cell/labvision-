import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { specsToText } from "@/lib/text";
import { saveProduct } from "../../actions";

type P = { slug: string; name: string; tagline: string; status: string; video_url: string; overview: string[]; specs: [string, string][]; standards: string[]; published: boolean };

export default async function Products() {
  await requireUser(["admin"]);
  const rows = await sql<P[]>`select slug, name, tagline, status, video_url, overview, specs, standards, published from products order by position`;
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Products</h1>
      <p>Edit the text shown on the public site. Specifications: one per line as <code>Label | Value</code>. Overview: separate paragraphs with a blank line.</p>
      {rows.map((p) => (
        <details key={p.slug}><summary>{p.name} ({p.status})</summary>
          <form action={saveProduct} style={{ paddingBottom: 16 }}><input type="hidden" name="slug" value={p.slug} />
            <label>Name<input name="name" defaultValue={p.name} required maxLength={120} /></label>
            <label>Tagline<input name="tagline" defaultValue={p.tagline} required maxLength={300} /></label>
            <label>Status<select name="status" defaultValue={p.status}><option value="coming_soon">Coming soon</option><option value="available">Available</option></select></label>
            <label>Demo video (YouTube link, or a file path starting with /)<input name="video" defaultValue={p.video_url} maxLength={300} /></label>
            <label>Overview<textarea name="overview" rows={6} defaultValue={p.overview.join("\n\n")} /></label>
            <label>Specifications<textarea name="specs" rows={8} defaultValue={specsToText(p.specs)} /></label>
            <label>Safety and standards (one per line)<textarea name="standards" rows={4} defaultValue={p.standards.join("\n")} /></label>
            <label className="ck"><input type="checkbox" name="published" defaultChecked={p.published} /> Published</label>
            <button className="btn">Save {p.name}</button></form></details>))}
    </>
  );
}
