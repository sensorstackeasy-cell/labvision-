import { requireUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { open } from "@/lib/secretbox";
import { otpauthUri } from "@/lib/totp";
import { changePassword, confirmMfa, disableMfa, startMfa } from "../../actions";

export default async function Security({ searchParams }: { searchParams: Promise<{ error?: string; ok?: string }> }) {
  const u = await requireUser();
  const { error, ok } = await searchParams;
  const [r] = await sql<{ enc: string | null }[]>`select totp_secret_enc as enc from users where id = ${u.id}`;
  const secret = r?.enc && !u.totp_enabled ? open(r.enc) : null; // shown only while setting up
  return (
    <>
      <h1 style={{ fontSize: 34 }}>Account security</h1>
      {ok && <p role="status">Two-step verification is on.</p>}
      <h2 style={{ fontSize: 24 }}>Two-step verification</h2>
      {u.totp_enabled ? (
        <form action={disableMfa} className="card" style={{ maxWidth: 420 }}><p>On. You need a code from your authenticator app each time you sign in.</p>
          <label>Your password to turn it off<input name="password" type="password" required autoComplete="current-password" /></label><button className="btn ghost">Turn off</button>
          {error === "pw" && <p role="alert" className="err">Incorrect password.</p>}</form>
      ) : secret ? (
        <form action={confirmMfa} className="card" style={{ maxWidth: 520 }}>
          <p>Add this key to an authenticator app (Google Authenticator, Microsoft Authenticator, Authy) as a time-based account, then enter the 6-digit code to confirm.</p>
          <p><code style={{ wordBreak: "break-all" }}>{secret}</code></p><p className="note">Or open this link on your phone: <code style={{ wordBreak: "break-all" }}>{otpauthUri(secret, u.email)}</code></p>
          <label>Code<input name="code" inputMode="numeric" maxLength={6} required autoComplete="off" /></label><button className="btn">Confirm and turn on</button>
          {error === "1" && <p role="alert" className="err">That code was not correct. Try the next code.</p>}</form>
      ) : (
        <form action={startMfa}><p>Protect your account with a second step. Admins should turn this on.</p><button className="btn">Set up two-step verification</button></form>
      )}
      <h2 style={{ fontSize: 24, marginTop: 32 }}>Change password</h2>
      <form action={changePassword} className="card" style={{ maxWidth: 420 }}>
        <label>Current password<input name="current" type="password" required autoComplete="current-password" /></label>
        <label>New password (12+ characters)<input name="next" type="password" minLength={12} required autoComplete="new-password" /></label>
        <button className="btn">Change password</button>{error === "pw" && <p role="alert" className="err">Check your current password and use 12 or more characters.</p>}
      </form>
    </>
  );
}
