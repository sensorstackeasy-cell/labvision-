import { currentUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { audit } from "@/lib/audit";
import { readPrivate, signedUrl } from "@/lib/storage";
import { safeFilename } from "@/lib/files";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const u = await currentUser();
  if (!u || u.role !== "admin") return new Response("Forbidden", { status: 403 });
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new Response("Not found", { status: 404 });
  const [a] = await sql<{ cv_key: string | null; cv_name: string | null }[]>`select cv_key, cv_name from applications where id = ${id}`;
  if (!a?.cv_key) return new Response("Not found", { status: 404 });
  await audit(u.id, "cv.download", "application", id);
  const url = await signedUrl(a.cv_key);
  if (url) return Response.redirect(url, 302);
  const buf = await readPrivate(a.cv_key);
  return new Response(new Uint8Array(buf), {
    headers: { "content-type": "application/octet-stream", "content-disposition": `attachment; filename="${safeFilename(a.cv_name ?? "cv")}"`, "x-content-type-options": "nosniff", "cache-control": "private, no-store" },
  });
}
