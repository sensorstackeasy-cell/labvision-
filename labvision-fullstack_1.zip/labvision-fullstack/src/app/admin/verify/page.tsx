import { redirect } from "next/navigation";
import { hasPendingMfa } from "@/lib/auth";
import { verifyMfaAction } from "../actions";

export const metadata = { title: "Two-step verification", robots: { index: false } };

export default async function Verify({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (!(await hasPendingMfa())) redirect("/admin/login");
  const { error } = await searchParams;
  return (
    <div className="wrap" style={{ maxWidth: 420, paddingTop: 80 }}>
      <h1 style={{ fontSize: 34 }}>Two-step verification</h1>
      <form className="card" action={verifyMfaAction}>
        <label htmlFor="code">6-digit code from your authenticator app</label>
        <input id="code" name="code" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} autoComplete="one-time-code" required autoFocus />
        <button className="btn">Verify</button>
        {error && <p role="alert" className="err">{error === "rate" ? "Too many attempts. Try again later." : "That code was not correct."}</p>}
      </form>
    </div>
  );
}
