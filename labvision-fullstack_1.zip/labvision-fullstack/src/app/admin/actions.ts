"use server";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { sql, j } from "@/lib/db";
import { login, logout, requireUser, verifyMfa, verifyPassword } from "@/lib/auth";
import { newSecret, otpauthUri, verifyTotp } from "@/lib/totp";
import { open, seal } from "@/lib/secretbox";
import { audit } from "@/lib/audit";
import { allow } from "@/lib/ratelimit";
import { notify } from "@/lib/mail";
import { lines, paragraphs, parseSpecs } from "@/lib/text";

const str = (f: FormData, k: string) => String(f.get(k) ?? "").trim();
const uuid = z.string().uuid();

export async function loginAction(f: FormData) {
  const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!allow(`login:${ip}`, 10, 15 * 60_000)) redirect("/admin/login?error=rate");
  const r = await login(str(f, "email"), String(f.get("password") ?? ""));
  redirect(r === "ok" ? "/admin" : r === "mfa" ? "/admin/verify" : "/admin/login?error=1");
}

export async function logoutAction() { await logout(); redirect("/admin/login"); }

export async function setEnquiryStatus(f: FormData) {
  const u = await requireUser();
  const id = uuid.parse(str(f, "id")), status = z.enum(["new", "in_progress", "quoted", "won", "closed"]).parse(str(f, "status"));
  await sql`update enquiries set status = ${status} where id = ${id}`;
  await audit(u.id, "enquiry.status", "enquiry", id, { status });
  revalidatePath("/admin"); revalidatePath(`/admin/enquiries/${id}`);
}

export async function addNote(f: FormData) {
  const u = await requireUser();
  const id = uuid.parse(str(f, "id")), body = z.string().min(1).max(2000).parse(str(f, "body"));
  await sql`insert into enquiry_notes (enquiry_id, user_id, body) values (${id}, ${u.id}, ${body})`;
  await audit(u.id, "enquiry.note", "enquiry", id);
  revalidatePath(`/admin/enquiries/${id}`);
}

export async function setApplicationStatus(f: FormData) {
  const u = await requireUser(["admin"]);
  const id = uuid.parse(str(f, "id")), status = z.enum(["new", "shortlisted", "interview", "offer", "rejected"]).parse(str(f, "status"));
  await sql`update applications set status = ${status} where id = ${id}`;
  await audit(u.id, "application.status", "application", id, { status });
  revalidatePath("/admin/applications");
}

export async function saveProduct(f: FormData) {
  const u = await requireUser(["admin"]);
  const slug = z.string().regex(/^[a-z0-9-]{1,60}$/).parse(str(f, "slug"));
  const status = z.enum(["coming_soon", "available"]).parse(str(f, "status"));
  await sql`update products set name = ${str(f, "name").slice(0, 120)}, tagline = ${str(f, "tagline").slice(0, 300)}, status = ${status}, video_url = ${z.string().max(300).refine((v) => v === "" || /^(https:\/\/|\/)/.test(v)).parse(str(f, "video"))},
    overview = ${j(paragraphs(str(f, "overview")))}, specs = ${j(parseSpecs(str(f, "specs")))}, standards = ${j(lines(str(f, "standards")))},
    published = ${f.get("published") === "on"}, updated_at = now() where slug = ${slug}`;
  await audit(u.id, "product.save", "product", slug);
  revalidatePath("/", "layout");
}

export async function addCertificate(f: FormData) {
  const u = await requireUser(["admin"]);
  const d = z.object({ name: z.string().min(2).max(150), description: z.string().max(400), number: z.string().max(80), url: z.string().max(400).refine((v) => v === "" || /^https?:\/\//.test(v)),
    valid: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).or(z.literal("")) })
    .parse({ name: str(f, "name"), description: str(f, "description"), number: str(f, "number"), url: str(f, "url"), valid: str(f, "valid") });
  const [r] = await sql<{ id: string }[]>`insert into certificates (name, description, number, url, valid_until, published)
    values (${d.name}, ${d.description}, ${d.number}, ${d.url}, ${d.valid || null}, ${f.get("published") === "on"}) returning id`;
  await audit(u.id, "certificate.add", "certificate", r.id);
  revalidatePath("/admin/certificates"); revalidatePath("/certificates");
}

export async function deleteCertificate(f: FormData) {
  const u = await requireUser(["admin"]);
  const id = uuid.parse(str(f, "id"));
  await sql`delete from certificates where id = ${id}`;
  await audit(u.id, "certificate.delete", "certificate", id);
  revalidatePath("/admin/certificates"); revalidatePath("/certificates");
}

export async function createUser(f: FormData) {
  const u = await requireUser(["admin"]);
  const d = z.object({ name: z.string().min(2).max(100), email: z.string().email().max(200), role: z.enum(["admin", "sales"]), password: z.string().min(12).max(200) })
    .parse({ name: str(f, "name"), email: str(f, "email").toLowerCase(), role: str(f, "role"), password: String(f.get("password") ?? "") });
  const [r] = await sql<{ id: string }[]>`insert into users (email, name, role, password_hash) values (${d.email}, ${d.name}, ${d.role}, ${await bcrypt.hash(d.password, 12)}) returning id`;
  await audit(u.id, "user.create", "user", r.id, { role: d.role });
  revalidatePath("/admin/users");
}

export async function setUserActive(f: FormData) {
  const u = await requireUser(["admin"]);
  const id = uuid.parse(str(f, "id")), active = str(f, "active") === "true";
  if (id === u.id) return; // you cannot lock yourself out
  await sql`update users set active = ${active} where id = ${id}`;
  if (!active) await sql`delete from sessions where user_id = ${id}`;
  await audit(u.id, active ? "user.enable" : "user.disable", "user", id);
  revalidatePath("/admin/users");
}

export async function verifyMfaAction(f: FormData) {
  const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!allow(`mfa:${ip}`, 10, 15 * 60_000)) redirect("/admin/verify?error=rate");
  redirect((await verifyMfa(str(f, "code"))) ? "/admin" : "/admin/verify?error=1");
}

/** Step 1 of enabling two-step verification: store a new secret (encrypted) that is not active until confirmed. */
export async function startMfa() {
  const u = await requireUser();
  await sql`update users set totp_secret_enc = ${seal(newSecret())}, totp_enabled = false where id = ${u.id}`;
  revalidatePath("/admin/security");
}
export async function confirmMfa(f: FormData) {
  const u = await requireUser();
  const [r] = await sql<{ enc: string | null }[]>`select totp_secret_enc as enc from users where id = ${u.id}`;
  if (!r?.enc || !verifyTotp(open(r.enc), str(f, "code"))) redirect("/admin/security?error=1");
  await sql`update users set totp_enabled = true where id = ${u.id}`;
  await audit(u.id, "mfa.enabled", "user", u.id);
  redirect("/admin/security?ok=1");
}
export async function disableMfa(f: FormData) {
  const u = await requireUser();
  if (!(await verifyPassword(u.id, String(f.get("password") ?? "")))) redirect("/admin/security?error=pw");
  await sql`update users set totp_enabled = false, totp_secret_enc = null where id = ${u.id}`;
  await audit(u.id, "mfa.disabled", "user", u.id);
  redirect("/admin/security");
}
export async function changePassword(f: FormData) {
  const u = await requireUser();
  const next = z.string().min(12).max(200).safeParse(String(f.get("next") ?? ""));
  if (!next.success || !(await verifyPassword(u.id, String(f.get("current") ?? "")))) redirect("/admin/security?error=pw");
  await sql`update users set password_hash = ${await bcrypt.hash(next.data, 12)} where id = ${u.id}`;
  await sql`delete from sessions where user_id = ${u.id}`; // sign out everywhere; the user signs in again
  await audit(u.id, "password.change", "user", u.id);
  redirect("/admin/login");
}

export async function setComplianceStatus(f: FormData) {
  const u = await requireUser(["admin"]);
  const id = uuid.parse(str(f, "id")), status = z.enum(["in_process", "design_basis", "issued"]).parse(str(f, "status"));
  await sql`update compliance_status set status = ${status}, note = ${str(f, "note").slice(0, 300)} where id = ${id}`;
  await audit(u.id, "compliance.save", "compliance", id, { status });
  revalidatePath("/quality"); revalidatePath("/admin/compliance");
}
export async function setCertificateStatus(f: FormData) {
  const u = await requireUser(["admin"]);
  const id = uuid.parse(str(f, "id")), status = z.enum(["in_process", "issued"]).parse(str(f, "status"));
  const url = z.string().max(400).refine((v) => v === "" || /^https?:\/\//.test(v)).parse(str(f, "url"));
  await sql`update certificates set status = ${status}, url = ${url}, number = ${str(f, "number").slice(0, 80)} where id = ${id}`;
  await audit(u.id, "certificate.status", "certificate", id, { status });
  revalidatePath("/certificates"); revalidatePath("/quality"); revalidatePath("/admin/certificates");
}
export async function saveSettings(f: FormData) {
  const u = await requireUser(["admin"]);
  await sql`insert into settings (key, value) values ('coming_soon', ${f.get("coming_soon") === "on" ? "true" : "false"}) on conflict (key) do update set value = excluded.value`;
  await audit(u.id, "settings.save", "settings", "coming_soon");
  revalidatePath("/", "layout");
}
export async function savePost(f: FormData) {
  const u = await requireUser(["admin"]);
  const d = z.object({ slug: z.string().regex(/^[a-z0-9-]{3,80}$/), title: z.string().min(3).max(160), summary: z.string().max(300), body: z.string().min(10).max(20000) })
    .parse({ slug: str(f, "slug"), title: str(f, "title"), summary: str(f, "summary"), body: str(f, "body") });
  const pub = f.get("published") === "on";
  await sql`insert into posts (slug, title, summary, body, published, published_at) values (${d.slug}, ${d.title}, ${d.summary}, ${d.body}, ${pub}, ${pub ? new Date() : null})
    on conflict (slug) do update set title = excluded.title, summary = excluded.summary, body = excluded.body, published = excluded.published,
    published_at = case when excluded.published and posts.published_at is null then now() else posts.published_at end`;
  await audit(u.id, "post.save", "post", d.slug);
  revalidatePath("/news"); revalidatePath("/", "layout");
}
export async function deletePost(f: FormData) {
  const u = await requireUser(["admin"]);
  const id = uuid.parse(str(f, "id"));
  await sql`delete from posts where id = ${id}`;
  await audit(u.id, "post.delete", "post", id);
  revalidatePath("/news"); revalidatePath("/", "layout");
}

export async function sendTestEmail() {
  const u = await requireUser(["admin"]);
  let result = "failed";
  try { result = await notify("Test email from the Labvision MedTech website", `This is a test sent by ${u.email}. If you can read it, enquiries and applications will reach this mailbox.`); } catch (e) { console.error("test email failed", e); }
  await audit(u.id, "email.test", "settings", "", { result });
  redirect(`/admin/settings?mail=${result}`);
}
