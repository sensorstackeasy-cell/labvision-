import { currentUser } from "@/lib/auth";
import { sql } from "@/lib/db";
import { audit } from "@/lib/audit";
import { toCsv } from "@/lib/csv";

export async function GET() {
  const u = await currentUser();
  if (!u || u.role !== "admin") return new Response("Forbidden", { status: 403 });
  const rows = await sql<Record<string, unknown>[]>`select ref, created_at, kind, status, name, email, phone, organisation, product, message from enquiries order by created_at desc`;
  await audit(u.id, "enquiries.export", "enquiry", "", { rows: rows.length });
  const head = ["Reference", "Received", "Type", "Status", "Name", "Email", "Phone", "Organisation", "Product", "Message"];
  return new Response(toCsv([head, ...rows.map((r) => Object.values(r))]), { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": 'attachment; filename="enquiries.csv"', "cache-control": "private, no-store" } });
}
