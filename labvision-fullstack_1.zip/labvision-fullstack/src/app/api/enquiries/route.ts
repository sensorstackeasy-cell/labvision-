import { NextResponse } from "next/server";
import { sql, j } from "@/lib/db";
import { enquirySchema, firstError } from "@/lib/validate";
import { allow } from "@/lib/ratelimit";
import { clientIp, sameOrigin } from "@/lib/request";
import { notify } from "@/lib/mail";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (!allow(`enq:${clientIp(req)}`, 5, 10 * 60_000)) return NextResponse.json({ error: "Too many requests. Please try again later." }, { status: 429 });
  if (Number(req.headers.get("content-length") ?? 0) > 20_000) return NextResponse.json({ error: "Request too large" }, { status: 413 });

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid request" }, { status: 400 }); }
  if (body && typeof body.website === "string" && body.website !== "") return NextResponse.json({ ok: true }); // honeypot: pretend success

  const parsed = enquirySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: firstError(parsed.error) }, { status: 422 });
  const d = parsed.data;

  const [row] = await sql<{ ref: string }[]>`insert into enquiries (kind, name, email, phone, organisation, product, message, details)
    values (${d.kind}, ${d.name}, ${d.email}, ${d.phone}, ${d.organisation}, ${d.product}, ${d.message}, ${j(d.details)}) returning ref`;
  const reference = row.ref;

  notify(`Website ${d.kind} [${reference}]: ${d.name}`,
    [`Reference: ${reference}`, `Type: ${d.kind}`, `Product: ${d.product}`, `Name: ${d.name}`, `Organisation: ${d.organisation}`, `Email: ${d.email}`, `Phone: ${d.phone}`,
     ...Object.entries(d.details).map(([k, v]) => `${k}: ${v}`), "", d.message].join("\n"), d.email).catch((e) => console.error("mail failed", e));

  return NextResponse.json({ ok: true, reference }, { status: 201 });
}
