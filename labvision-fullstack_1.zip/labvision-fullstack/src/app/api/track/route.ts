import { NextResponse } from "next/server";
import { sql } from "@/lib/db";
import { allow } from "@/lib/ratelimit";
import { clientIp } from "@/lib/request";

const ENQ: Record<string, string> = { new: "Received", in_progress: "Being handled", quoted: "Quotation sent", won: "Completed", closed: "Closed" };
const APP: Record<string, string> = { new: "Received", shortlisted: "Under review", interview: "Interview stage", offer: "Offer stage", rejected: "Closed" };
const NOT_FOUND = { error: "No request found for that reference and email." };

export async function GET(req: Request) {
  if (!allow(`track:${clientIp(req)}`, 10, 10 * 60_000)) return NextResponse.json({ error: "Too many attempts. Please try again later." }, { status: 429 });
  const u = new URL(req.url), ref = (u.searchParams.get("ref") ?? "").trim().toUpperCase(), email = (u.searchParams.get("email") ?? "").trim().toLowerCase();
  if (!/^[0-9A-F]{8}$/.test(ref) || email.length > 200) return NextResponse.json(NOT_FOUND, { status: 404 });
  // The reference alone is not enough: the email must match too, so references cannot be enumerated. No personal data is returned.
  const [e] = await sql<{ kind: string; product: string; status: string; created_at: Date }[]>`select kind, product, status, created_at from enquiries where ref = ${ref} and lower(email) = ${email}`;
  if (e) return NextResponse.json({ label: `${e.kind} request${e.product ? ` for ${e.product}` : ""}`, status: ENQ[e.status] ?? e.status, date: e.created_at.toISOString().slice(0, 10) });
  const [a] = await sql<{ role: string; status: string; created_at: Date }[]>`select role, status, created_at from applications where ref = ${ref} and lower(email) = ${email}`;
  if (a) return NextResponse.json({ label: `Application for ${a.role}`, status: APP[a.status] ?? a.status, date: a.created_at.toISOString().slice(0, 10) });
  return NextResponse.json(NOT_FOUND, { status: 404 });
}
