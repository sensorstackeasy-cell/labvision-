import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { sql } from "@/lib/db";
import { applicationSchema, firstError } from "@/lib/validate";
import { allow } from "@/lib/ratelimit";
import { clientIp, sameOrigin } from "@/lib/request";
import { CV_MAX_BYTES, detectCv } from "@/lib/files";
import { putPrivate } from "@/lib/storage";
import { notify } from "@/lib/mail";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (!allow(`app:${clientIp(req)}`, 3, 60 * 60_000)) return NextResponse.json({ error: "Too many applications from this connection. Please try later." }, { status: 429 });
  if (Number(req.headers.get("content-length") ?? 0) > CV_MAX_BYTES + 100_000) return NextResponse.json({ error: "File is larger than 5 MB" }, { status: 413 });

  let fd: FormData;
  try { fd = await req.formData(); } catch { return NextResponse.json({ error: "Invalid request" }, { status: 400 }); }
  if (String(fd.get("website") ?? "") !== "") return NextResponse.json({ ok: true });

  const parsed = applicationSchema.safeParse({
    role: fd.get("role"), name: fd.get("name"), email: fd.get("email"), phone: fd.get("phone") ?? "",
    experience: fd.get("experience") ?? "", city: fd.get("city") ?? "", qualification: fd.get("qualification") ?? "",
    link: fd.get("link") ?? "", message: fd.get("message") ?? "", consent: fd.get("consent") === "on",
  });
  if (!parsed.success) return NextResponse.json({ error: firstError(parsed.error) }, { status: 422 });
  const d = parsed.data;

  let cvKey: string | null = null, cvName: string | null = null;
  const file = fd.get("cv");
  if (file instanceof File && file.size > 0) {
    const buf = Buffer.from(await file.arrayBuffer());
    const kind = detectCv(buf, file.name);
    if (!kind) return NextResponse.json({ error: "CV must be a PDF, DOC or DOCX file under 5 MB" }, { status: 422 });
    cvKey = `cv/${randomUUID()}.${kind.ext}`;
    cvName = file.name.slice(0, 120);
    await putPrivate(cvKey, buf, kind.mime); // TODO production: scan for malware before storing, for example with an S3 event and a scanner
  }

  const [row] = await sql<{ ref: string }[]>`insert into applications (role, name, email, phone, experience, city, qualification, link, message, cv_key, cv_name)
    values (${d.role}, ${d.name}, ${d.email}, ${d.phone}, ${d.experience}, ${d.city}, ${d.qualification}, ${d.link}, ${d.message}, ${cvKey}, ${cvName}) returning ref`;
  const reference = row.ref;
  notify(`Job application [${reference}]: ${d.role} - ${d.name}`,
    [`Reference: ${reference}`, `Position: ${d.role}`, `Name: ${d.name}`, `Email: ${d.email}`, `Phone: ${d.phone}`, `City: ${d.city}`, `Experience: ${d.experience}`,
     `Qualification: ${d.qualification}`, `Profile link: ${d.link}`, `CV: ${cvName ? `uploaded (${cvName}). Download it from the admin dashboard, Applications page.` : "not uploaded"}`, "", d.message].join("\n"), d.email)
    .catch((e) => console.error("mail failed", e));
  return NextResponse.json({ ok: true, reference }, { status: 201 });
}
