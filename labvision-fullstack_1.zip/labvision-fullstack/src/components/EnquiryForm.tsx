"use client";
import { useState, type FormEvent } from "react";

export type Kind = "contact" | "quotation" | "service" | "document" | "distributor" | "demo";
type State = { s: "idle" | "sending" | "done" | "error"; msg?: string; ref?: string };

export default function EnquiryForm({ kind, products, defaultProduct = "" }: { kind: Kind; products: string[]; defaultProduct?: string }) {
  const [st, setSt] = useState<State>({ s: "idle" });

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const v = (k: string) => String(f.get(k) ?? "");
    setSt({ s: "sending" });
    const body = {
      kind, name: v("name"), email: v("email"), phone: v("phone"), organisation: v("organisation"), product: v("product"), message: v("message"),
      details: kind === "distributor" ? { city: v("city"), brands: v("brands"), years: v("years") } : kind === "demo" ? { visit_date: v("visit_date"), city: v("city") } : kind === "quotation" ? { quantity: v("quantity"), city: v("city") } : {}, consent: f.get("consent") === "on", website: v("website"),
    };
    try {
      const r = await fetch("/api/enquiries", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      const j = await r.json();
      setSt(r.ok ? { s: "done", ref: j.reference } : { s: "error", msg: j.error ?? "Something went wrong" });
    } catch { setSt({ s: "error", msg: "Network error. Please try again or call us." }); }
  }

  if (st.s === "done") return <div className="card" role="status"><h3>Thank you</h3><p>We have received your request.{st.ref && <> Your reference is <b>{st.ref}</b>.</>} We will reply by email or phone.</p></div>;

  return (
    <form className="card" onSubmit={onSubmit} noValidate>
      <div className="two"><div><label htmlFor="name">Name</label><input id="name" name="name" autoComplete="name" required /></div>
        <div><label htmlFor="organisation">Organisation</label><input id="organisation" name="organisation" autoComplete="organization" /></div></div>
      <div className="two"><div><label htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required /></div>
        <div><label htmlFor="phone">Phone</label><input id="phone" name="phone" type="tel" autoComplete="tel" /></div></div>
      {kind !== "distributor" && <><label htmlFor="product">Product</label>
        <select id="product" name="product" defaultValue={defaultProduct}><option value="">Select a product</option>{products.map((p) => <option key={p}>{p}</option>)}<option>Complete product range</option><option>OEM or distribution</option><option>Service or spare parts</option><option>Certificates and documents</option></select></>}
      {kind === "quotation" && <div className="two"><div><label htmlFor="quantity">Quantity</label><input id="quantity" name="quantity" type="number" min={1} defaultValue={1} /></div><div><label htmlFor="city">Delivery city</label><input id="city" name="city" /></div></div>}
      {kind === "demo" && <div className="two"><div><label htmlFor="visit_date">Preferred date</label><input id="visit_date" name="visit_date" type="date" /></div><div><label htmlFor="city">City</label><input id="city" name="city" /></div></div>}
      {kind === "distributor" && <><div className="two"><div><label htmlFor="city">City and territory</label><input id="city" name="city" /></div><div><label htmlFor="years">Years in medical equipment</label><select id="years" name="years"><option>Under 2</option><option>2 to 5</option><option>5 to 10</option><option>Over 10</option></select></div></div><label htmlFor="brands">Brands you currently represent</label><input id="brands" name="brands" /></>}
      <label htmlFor="message">Message</label><textarea id="message" name="message" rows={4} />
      <input name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hp" />
      <label className="ck"><input type="checkbox" name="consent" /> <span>I agree that Labvision MedTech may contact me about this request. <a href="/privacy">Privacy policy</a></span></label>
      <button className="btn" disabled={st.s === "sending"}>{st.s === "sending" ? "Sending..." : "Send"}</button>
      {st.s === "error" && <p role="alert" className="err">{st.msg}</p>}
    </form>
  );
}
