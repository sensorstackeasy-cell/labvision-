"use client";
import { useEffect, useRef } from "react";

const g = (x: number, m: number, w: number) => Math.exp(-(((x - m) / w) ** 2));
const F: Record<string, (t: number) => number> = {
  vent: (t) => { const x = (t % 4) / 4; return x < 0.3 ? x / 0.3 : x < 0.4 ? 1 : Math.exp(-(x - 0.4) * 7) * 0.98; },
  ecg: (t) => { const x = (t % 0.9) / 0.9; return 0.12 * g(x, 0.2, 0.04) - 0.1 * g(x, 0.37, 0.012) + g(x, 0.4, 0.014) - 0.18 * g(x, 0.43, 0.014) + 0.25 * g(x, 0.65, 0.06); },
  cgm: (t) => 0.5 + 0.22 * Math.sin(t * 0.35) + 0.12 * Math.sin(t * 0.9 + 1) + 0.05 * Math.sin(t * 2.3),
};
const P1 = (u: number) => 830 + 28 * Math.sin(u * 0.5) + 8 * Math.sin(u * 1.7), P2 = (u: number) => 1065 + 22 * Math.sin(u * 0.4 + 1) + 6 * Math.sin(u * 1.3);
const LABEL: Record<string, string> = { vent: "Airway pressure", ecg: "ECG lead II", cgm: "Glucose, last 2 hours", inc: "Chamber temperature" };

export default function Signal({ kind, color }: { kind: "vent" | "ecg" | "cgm" | "inc"; color: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!, x = c.getContext("2d")!;
    const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    const draw = (ms: number) => {
      const t = ms / 1000, d = devicePixelRatio || 1, w = c.clientWidth, h = c.clientHeight;
      if (c.width !== w * d) { c.width = w * d; c.height = h * d; }
      x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, h);
      const cs = getComputedStyle(c), ink = cs.getPropertyValue("--ink") || "#0c2a33", line = cs.getPropertyValue("--line") || "#cfdcdd", mut = cs.getPropertyValue("--mut") || "#4f6a72";
      x.strokeStyle = line; x.lineWidth = 1; for (let i = 1; i < 5; i++) { x.beginPath(); x.moveTo(0, (h * i) / 5); x.lineTo(w, (h * i) / 5); x.stroke(); }
      x.font = "600 14px system-ui"; x.fillStyle = ink; x.fillText(LABEL[kind], 8, 16);
      if (kind === "inc") {
        const Y = (v: number) => h * (0.9 - ((v - 700) / 450) * 0.78);
        x.setLineDash([5, 5]); x.strokeStyle = mut; x.font = "12px system-ui";
        for (const m of [800, 1050]) { x.beginPath(); x.moveTo(0, Y(m)); x.lineTo(w, Y(m)); x.stroke(); x.fillStyle = mut; x.fillText(`minimum ${m}°C`, w - 100, Y(m) - 4); }
        x.setLineDash([]);
        for (const [fn, col] of [[P1, color], [P2, ink]] as const) { x.strokeStyle = col; x.lineWidth = 2.5; x.beginPath(); for (let px = 0; px <= w; px += 3) { const y = Y(fn(t - 20 + (px / w) * 20)); px ? x.lineTo(px, y) : x.moveTo(px, y); } x.stroke(); }
        x.fillStyle = color; x.fillText(`Primary ${P1(t).toFixed(0)}°C`, 8, 34); x.fillStyle = ink; x.fillText(`Secondary ${P2(t).toFixed(0)}°C`, 120, 34);
      } else {
        const span = kind === "ecg" ? 3.6 : kind === "vent" ? 8 : 24;
        if (kind === "cgm") { x.fillStyle = color + "22"; x.fillRect(0, h * (1 - 180 / 300), w, h * (110 / 300)); }
        x.strokeStyle = color; x.lineWidth = 2.5; x.lineJoin = "round"; x.beginPath();
        for (let px = 0; px <= w; px += 2) { const v = F[kind](t - span + (px / w) * span), y = kind === "cgm" ? h * (1 - (60 + v * 200) / 300) : h * (0.88 - v * 0.72); px ? x.lineTo(px, y) : x.moveTo(px, y); }
        x.stroke();
      }
      if (!still) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [kind, color]);
  return <canvas ref={ref} role="img" aria-label={`Simulated ${LABEL[kind].toLowerCase()} signal, not patient data`} style={{ width: "100%", height: 190, display: "block" }} />;
}
