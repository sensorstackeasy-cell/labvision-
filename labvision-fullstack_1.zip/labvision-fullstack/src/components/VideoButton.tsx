"use client";
import { useEffect, useState } from "react";

const yt = (u: string) => u.match(/(?:youtu\.be\/|v=|embed\/)([\w-]{11})/)?.[1] ?? (/^[\w-]{11}$/.test(u) ? u : null);

export default function VideoButton({ url, title }: { url: string; title: string }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", k); return () => document.removeEventListener("keydown", k);
  }, [open]);
  const id = yt(url);
  return (
    <>
      <button className="btn ghost" onClick={() => setOpen(true)}>Watch demo video</button>
      {open && (
        <div className="lb" role="dialog" aria-modal="true" aria-label={`${title} demo video`} onClick={() => setOpen(false)}>
          <div style={{ width: "min(960px,100%)" }} onClick={(e) => e.stopPropagation()}>
            <button className="btn" onClick={() => setOpen(false)} style={{ marginBottom: 10 }}>Close</button>
            {id ? <iframe src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`} title={`${title} demo video`} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen style={{ width: "100%", aspectRatio: "16/9", border: 0, borderRadius: 10 }} />
              : <video src={url} controls autoPlay playsInline style={{ width: "100%", borderRadius: 10 }} />}
          </div>
        </div>)}
    </>
  );
}
