"use client";
import Image from "next/image";
import { useEffect, useState } from "react";

export default function ZoomImage({ src, alt, w, h }: { src: string; alt: string; w: number; h: number }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", k); return () => document.removeEventListener("keydown", k);
  }, [open]);
  return (
    <>
      <button className="zoom" onClick={() => setOpen(true)} aria-label={`Enlarge: ${alt}`}><Image src={src} alt={alt} width={w} height={h} /></button>
      {open && <div className="lb" role="dialog" aria-modal="true" aria-label={alt} onClick={() => setOpen(false)}><Image src={src} alt={alt} width={w * 2} height={h * 2} /></div>}
    </>
  );
}
