"use client";
import Image from "next/image";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { useRouter } from "next/navigation";

type Tile = { slug: string; name: string; img: string; accent: string };

/** Full-screen welcome shown on every visit to the home page. */
export default function WelcomeGate({ tiles, soon }: { tiles: Tile[]; soon: boolean }) {
  const [show, setShow] = useState(true);
  const router = useRouter(), enter = useRef<HTMLButtonElement>(null);
  useEffect(() => { if (show) { enter.current?.focus(); document.body.style.overflow = "hidden"; } return () => { document.body.style.overflow = ""; }; }, [show]);
  if (!show) return null;
  return (
    <div className="welcome" role="dialog" aria-modal="true" aria-labelledby="wh">
      <div className="wi">
        <div className="wl">Labvision MedTech</div>
        {soon && <i className="soon big">Coming soon</i>}
        <h2 id="wh" className="wh">Welcome. Medical devices you can depend on, built in India.</h2>
        <p>Explore our portable ventilator, patient monitor, CGM system and biomedical waste incinerator, each with full technical detail.</p>
        <button ref={enter} className="btn" onClick={() => setShow(false)} style={{ background: "#e4efef", color: "#0c2a33" }}>Enter website</button>
        <div className="wtiles">
          {tiles.map((t) => (
            <button key={t.slug} className="wt" style={{ "--c": t.accent } as CSSProperties} onClick={() => { setShow(false); router.push(`/products/${t.slug}`); }}>
              <Image src={t.img} alt="" width={300} height={200} />{soon && <i className="soon">Coming soon</i>}<span>{t.name}</span>
            </button>))}
        </div>
      </div>
    </div>
  );
}
