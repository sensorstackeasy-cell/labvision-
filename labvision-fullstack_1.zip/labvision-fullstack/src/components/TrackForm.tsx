"use client";
import { useState, type FormEvent } from "react";

export default function TrackForm() {
  const [res, setRes] = useState<string>("");
  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setRes("Checking...");
    try {
      const r = await fetch(`/api/track?ref=${encodeURIComponent(String(f.get("ref")))}&email=${encodeURIComponent(String(f.get("email")))}`);
      const j = await r.json();
      setRes(r.ok ? `${j.label} (${j.date}). Current status: ${j.status}.` : j.error ?? "Not found");
    } catch { setRes("Network error. Please try again."); }
  }
  return (
    <form className="card" onSubmit={onSubmit} style={{ maxWidth: 480 }}>
      <label htmlFor="ref">Reference number</label><input id="ref" name="ref" required maxLength={12} autoComplete="off" />
      <label htmlFor="email">Email you used</label><input id="email" name="email" type="email" required />
      <button className="btn">Check status</button>
      {res && <p role="status" style={{ marginTop: 12 }}>{res}</p>}
    </form>
  );
}
