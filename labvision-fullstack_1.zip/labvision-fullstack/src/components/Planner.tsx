"use client";
import Link from "next/link";
import { useState } from "react";
import { plan, type Unit } from "@/lib/planner";

export default function Planner() {
  const [beds, setBeds] = useState(10), [unit, setUnit] = useState<Unit>("icu");
  const r = plan(beds, unit);
  return (
    <div className="card" style={{ maxWidth: 560 }}>
      <label htmlFor="unit">Department</label>
      <select id="unit" value={unit} onChange={(e) => setUnit(e.target.value as Unit)}><option value="icu">ICU</option><option value="hdu">High dependency unit</option><option value="emergency">Emergency room</option><option value="ward">General ward</option></select>
      <label htmlFor="beds">Number of beds</label>
      <input id="beds" type="number" min={0} max={500} value={beds} onChange={(e) => setBeds(Number(e.target.value))} />
      <div className="stats"><div><b>{r.monitors}</b><span>patient monitors</span></div><div><b>{r.ventilators}</b><span>portable ventilators</span></div></div>
      <p className="note">A starting point for discussion, not clinical advice. Your clinical and biomedical teams decide the real numbers.</p>
      <Link className="btn" href={`/quotation?product=${encodeURIComponent("Complete product range")}`}>Request quotation for these numbers</Link>
    </div>
  );
}
