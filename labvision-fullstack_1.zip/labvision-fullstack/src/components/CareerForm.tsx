"use client";
import { useState, type FormEvent } from "react";

type State = { s: "idle" | "sending" | "done" | "error"; msg?: string; ref?: string };

export default function CareerForm({ roles, defaultRole = "" }: { roles: string[]; defaultRole?: string }) {
  const [st, setSt] = useState<State>({ s: "idle" });

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const cv = f.get("cv");
    if (cv instanceof File && cv.size > 5 * 1024 * 1024) return setSt({ s: "error", msg: "CV must be under 5 MB" });
    setSt({ s: "sending" });
    try {
      const r = await fetch("/api/applications", { method: "POST", body: f }); // browser sets the multipart boundary
      const j = await r.json();
      setSt(r.ok ? { s: "done", ref: j.reference } : { s: "error", msg: j.error ?? "Something went wrong" });
    } catch { setSt({ s: "error", msg: "Network error. Please try again." }); }
  }

  if (st.s === "done") return <div className="card" role="status"><h3>Application received</h3><p>Thank you. Your reference is <b>{st.ref}</b>. We will contact you if your profile matches an opening.</p></div>;

  return (
    <form className="card" onSubmit={onSubmit} noValidate>
      <label htmlFor="role">Position</label>
      <select id="role" name="role" defaultValue={defaultRole}>{roles.map((r) => <option key={r}>{r}</option>)}<option>General application</option></select>
      <div className="two"><div><label htmlFor="name">Full name</label><input id="name" name="name" autoComplete="name" required /></div>
        <div><label htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required /></div></div>
      <div className="two"><div><label htmlFor="phone">Phone</label><input id="phone" name="phone" type="tel" autoComplete="tel" required /></div>
        <div><label htmlFor="city">Current city</label><input id="city" name="city" /></div></div>
      <div className="two"><div><label htmlFor="experience">Experience</label><select id="experience" name="experience"><option>Fresher</option><option>Under 2 years</option><option>2 to 5 years</option><option>5 to 10 years</option><option>Over 10 years</option></select></div>
        <div><label htmlFor="qualification">Highest qualification</label><input id="qualification" name="qualification" /></div></div>
      <label htmlFor="link">LinkedIn or portfolio link (optional)</label><input id="link" name="link" type="url" placeholder="https://" />
      <label htmlFor="cv">CV (PDF, DOC or DOCX, up to 5 MB)</label><input id="cv" name="cv" type="file" accept=".pdf,.doc,.docx" />
      <label htmlFor="message">Why do you want to join Labvision MedTech?</label><textarea id="message" name="message" rows={4} />
      <input name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hp" />
      <label className="ck"><input type="checkbox" name="consent" /> <span>I agree that Labvision MedTech may store my details and CV to consider my application. <a href="/privacy">Privacy policy</a></span></label>
      <button className="btn" disabled={st.s === "sending"}>{st.s === "sending" ? "Uploading..." : "Submit application"}</button>
      {st.s === "error" && <p role="alert" className="err">{st.msg}</p>}
    </form>
  );
}
