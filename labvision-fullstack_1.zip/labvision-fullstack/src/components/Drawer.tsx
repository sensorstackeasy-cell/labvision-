"use client";
import Link from "next/link";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import type { NavItem } from "@/lib/nav";

export default function Drawer({ items, phone, tel, email }: { items: NavItem[]; phone: string; tel: string; email: string }) {
  const [open, setOpen] = useState(false);
  const first = useRef<HTMLAnchorElement>(null), btn = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    first.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { setOpen(false); btn.current?.focus(); } };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open]);
  return (
    <>
      <button ref={btn} className="iconbtn" aria-label="Open menu" aria-expanded={open} aria-controls="drawer" onClick={() => setOpen(true)}>
        <svg width="20" height="14" viewBox="0 0 20 14" aria-hidden="true"><path d="M0 1h20M0 7h20M0 13h20" stroke="currentColor" strokeWidth="2" /></svg>
      </button>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}
      <aside id="drawer" className={open ? "drawer open" : "drawer"} aria-label="Site menu" hidden={!open}>
        <div className="dh"><b>Menu</b><button className="iconbtn" aria-label="Close menu" onClick={() => { setOpen(false); btn.current?.focus(); }}>&#10005;</button></div>
        <nav aria-label="Sections">
          {items.map((it, i) => <Link key={it.href} ref={i === 0 ? first : undefined} href={it.href} onClick={() => setOpen(false)} style={{ "--c": it.c ?? "transparent" } as CSSProperties}>{it.label}</Link>)}
        </nav>
        <Link className="btn" href="/quotation" onClick={() => setOpen(false)} style={{ width: "100%", textAlign: "center" }}>Request quotation</Link>
        <p className="df"><a href={`tel:${tel}`}>{phone}</a><br /><a href={`mailto:${email}`}>{email}</a></p>
      </aside>
    </>
  );
}
