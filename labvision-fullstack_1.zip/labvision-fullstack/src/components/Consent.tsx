"use client";
import Link from "next/link";
import { useEffect, useState } from "react";

const GA = process.env.NEXT_PUBLIC_GA_ID;

/** Google Analytics loads only after the visitor accepts. With no NEXT_PUBLIC_GA_ID there is no banner and no tracking. */
export default function Consent() {
  const [state, setState] = useState<"unknown" | "yes" | "no">("unknown");
  useEffect(() => { if (GA) { try { setState((localStorage.getItem("lv-consent") as "yes" | "no") ?? "unknown"); } catch { /* storage blocked */ } } }, []);
  useEffect(() => {
    if (!GA || state !== "yes" || document.getElementById("ga-s")) return;
    const w = window as unknown as { dataLayer: unknown[]; gtag: (...a: unknown[]) => void };
    w.dataLayer = w.dataLayer || []; w.gtag = function () { w.dataLayer.push(arguments); };
    const s = document.createElement("script"); s.id = "ga-s"; s.async = true; s.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(GA)}`; document.head.appendChild(s);
    w.gtag("js", new Date()); w.gtag("config", GA, { anonymize_ip: true });
  }, [state]);
  if (!GA || state !== "unknown") return null;
  const choose = (v: "yes" | "no") => { try { localStorage.setItem("lv-consent", v); } catch { /* ignore */ } setState(v); };
  return (
    <div className="consent" role="region" aria-label="Analytics consent">
      <span>We use Google Analytics, with your consent, to count visits. <Link href="/privacy">Privacy policy</Link></span>
      <span className="row"><button className="btn" onClick={() => choose("yes")}>Accept</button><button className="btn ghost" onClick={() => choose("no")}>Decline</button></span>
    </div>
  );
}
