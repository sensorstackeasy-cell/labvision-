"use client";
import { useState } from "react";
import ZoomImage from "./ZoomImage";

type Props = {
  name: string; overview: string[]; how: { t: string; d: string }[]; specs: [string, string][]; standards: string[]; exploded: string;
};
const TABS = ["Overview", "How it works", "Specifications", "Safety and standards", "Exploded view"];

export default function ProductTabs({ name, overview, how, specs, standards, exploded }: Props) {
  const [tab, setTab] = useState(0);
  return (
    <div>
      <div className="tabs" role="tablist">
        {TABS.map((t, i) => <button key={t} role="tab" id={`tab-${i}`} aria-selected={tab === i} aria-controls="tabpanel" onClick={() => setTab(i)}>{t}</button>)}
      </div>
      <div id="tabpanel" role="tabpanel" aria-labelledby={`tab-${tab}`}>
        {tab === 0 && <>{overview.map((t, i) => <p key={i} className={i === 0 ? "lead" : ""}>{t}</p>)}</>}
        {tab === 1 && <ol>{how.map((h, i) => <li key={i}><b>{h.t}</b> {h.d}</li>)}</ol>}
        {tab === 2 && <table><tbody>{specs.map(([k, v]) => <tr key={k}><th scope="row">{k}</th><td>{v}</td></tr>)}</tbody></table>}
        {tab === 3 && <ul>{standards.map((s, i) => <li key={i}>{s}</li>)}</ul>}
        {tab === 4 && <><ZoomImage src={exploded} alt={`Exploded view of ${name}`} w={1500} h={1000} /><p className="note">Select the image to enlarge.</p></>}
      </div>
    </div>
  );
}
