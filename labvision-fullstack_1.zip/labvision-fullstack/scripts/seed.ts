import postgres from "postgres";
import bcrypt from "bcryptjs";
import { readFileSync } from "node:fs";

type Seed = {
  slug: string; position: number; name: string; tagline: string; accent: string; status: string;
  overview: unknown; how_it_works: unknown; specs: unknown; standards: unknown; stats: unknown;
  hero_image: string; exploded_image: string; catalog_pdf: string; related: string[]; signal: string; video_url: string;
};

async function main() {
  const sql = postgres(process.env.DATABASE_URL!, { max: 1 });
  const j = (v: unknown) => sql.json(v as postgres.JSONValue);

  const [{ n }] = await sql<{ n: number }[]>`select count(*)::int as n from users`;
  const email = process.env.ADMIN_EMAIL, password = process.env.ADMIN_PASSWORD;
  if (n === 0) {
    if (!email || !password || password.length < 12) throw new Error("Set ADMIN_EMAIL and an ADMIN_PASSWORD of 12+ characters for the first run.");
    await sql`insert into users (email, name, password_hash, role) values (${email}, 'Administrator', ${await bcrypt.hash(password, 12)}, 'admin')`;
    console.log("created admin", email);
  }

  const products: Seed[] = JSON.parse(readFileSync("seed/products.json", "utf8"));
  for (const p of products) {
    // do nothing on conflict so edits made in the admin CMS are never overwritten by a re-seed
    await sql`insert into products (slug, position, name, tagline, accent, status, overview, how_it_works, specs, standards, stats, hero_image, exploded_image, catalog_pdf, related, signal, video_url)
      values (${p.slug}, ${p.position}, ${p.name}, ${p.tagline}, ${p.accent}, ${p.status}, ${j(p.overview)}, ${j(p.how_it_works)}, ${j(p.specs)}, ${j(p.standards)}, ${j(p.stats)}, ${p.hero_image}, ${p.exploded_image}, ${p.catalog_pdf}, ${p.related}, ${p.signal}, ${p.video_url})
      on conflict (slug) do nothing`;
  }
  console.log("products ready:", products.length);

  const site = JSON.parse(readFileSync("seed/site.json", "utf8")) as { settings: Record<string, string>; compliance: string[][]; certificates: string[][] };
  for (const [k, v] of Object.entries(site.settings)) await sql`insert into settings (key, value) values (${k}, ${v}) on conflict (key) do nothing`;
  const [{ c }] = await sql<{ c: number }[]>`select count(*)::int as c from compliance_status`;
  if (c === 0) for (const [i, r] of site.compliance.entries()) await sql`insert into compliance_status (position, standard, scope, status, note) values (${i + 1}, ${r[0]}, ${r[1]}, ${r[2]}, ${r[3]})`;
  const [{ k }] = await sql<{ k: number }[]>`select count(*)::int as k from certificates`;
  if (k === 0) for (const r of site.certificates) await sql`insert into certificates (name, scope, status, published) values (${r[0]}, ${r[1]}, 'in_process', true)`;
  await sql.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
