import postgres from "postgres";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

async function main() {
  const sql = postgres(process.env.DATABASE_URL!, { max: 1 });
  await sql`create table if not exists schema_migrations (name text primary key, applied_at timestamptz not null default now())`;
  const done = new Set((await sql<{ name: string }[]>`select name from schema_migrations`).map((r) => r.name));
  for (const f of readdirSync("migrations").filter((x) => x.endsWith(".sql")).sort()) {
    if (done.has(f)) continue;
    await sql.begin(async (tx) => {
      await tx.unsafe(readFileSync(join("migrations", f), "utf8"));
      await tx`insert into schema_migrations (name) values (${f})`;
    });
    console.log("applied", f);
  }
  await sql.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
