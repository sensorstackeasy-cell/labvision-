-- Request tracking, demo bookings, MFA, news, settings, compliance table, product extras.
alter table enquiries drop constraint enquiries_kind_check;
alter table enquiries add constraint enquiries_kind_check check (kind in ('contact','quotation','service','document','distributor','demo'));

alter table enquiries add column ref text;
alter table applications add column ref text;
update enquiries set ref = upper(substr(md5(id::text), 1, 8)) where ref is null;
update applications set ref = upper(substr(md5(id::text), 1, 8)) where ref is null;
alter table enquiries alter column ref set default upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
alter table applications alter column ref set default upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
alter table enquiries alter column ref set not null;
alter table applications alter column ref set not null;
create unique index enquiries_ref on enquiries (ref);
create unique index applications_ref on applications (ref);

alter table products add column video_url text not null default '';
alter table products add column related text[] not null default '{}';
alter table products add column signal text not null default 'none';

alter table certificates add column status text not null default 'issued' check (status in ('in_process','issued'));
alter table certificates add column scope text not null default '';

create table compliance_status (
  id uuid primary key default gen_random_uuid(),
  position int not null,
  standard text not null,
  scope text not null,
  status text not null check (status in ('in_process','design_basis','issued')),
  note text not null default ''
);

create table settings (key text primary key, value text not null);

create table posts (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  summary text not null default '',
  body text not null,
  published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now()
);

alter table users add column totp_secret_enc text;
alter table users add column totp_enabled boolean not null default false;
alter table sessions add column mfa_ok boolean not null default true;
