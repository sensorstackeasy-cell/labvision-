create table users (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  name text not null,
  password_hash text not null,
  role text not null check (role in ('admin','sales')),
  active boolean not null default true,
  failed_logins int not null default 0,
  locked_until timestamptz,
  created_at timestamptz not null default now()
);
create unique index users_email_lower on users (lower(email));

create table sessions (
  token_hash text primary key,
  user_id uuid not null references users(id) on delete cascade,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index sessions_user on sessions (user_id);

create table enquiries (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('contact','quotation','service','document','distributor')),
  name text not null,
  email text not null,
  phone text not null default '',
  organisation text not null default '',
  product text not null default '',
  message text not null default '',
  details jsonb not null default '{}',
  status text not null default 'new' check (status in ('new','in_progress','quoted','won','closed')),
  consent_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index enquiries_status_created on enquiries (status, created_at desc);

create table enquiry_notes (
  id uuid primary key default gen_random_uuid(),
  enquiry_id uuid not null references enquiries(id) on delete cascade,
  user_id uuid not null references users(id),
  body text not null,
  created_at timestamptz not null default now()
);

create table applications (
  id uuid primary key default gen_random_uuid(),
  role text not null,
  name text not null,
  email text not null,
  phone text not null default '',
  experience text not null default '',
  city text not null default '',
  qualification text not null default '',
  link text not null default '',
  message text not null default '',
  cv_key text,
  cv_name text,
  status text not null default 'new' check (status in ('new','shortlisted','interview','offer','rejected')),
  consent_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table products (
  slug text primary key,
  position int not null,
  name text not null,
  tagline text not null,
  accent text not null default '#1B8A8F',
  status text not null default 'coming_soon' check (status in ('coming_soon','available')),
  overview jsonb not null default '[]',
  how_it_works jsonb not null default '[]',
  specs jsonb not null default '[]',
  standards jsonb not null default '[]',
  stats jsonb not null default '[]',
  hero_image text not null,
  exploded_image text not null,
  catalog_pdf text not null,
  published boolean not null default true,
  updated_at timestamptz not null default now()
);

create table certificates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  number text not null default '',
  valid_until date,
  url text not null default '',
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table audit_log (
  id bigserial primary key,
  at timestamptz not null default now(),
  user_id uuid references users(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text not null default '',
  detail jsonb not null default '{}'
);
create index audit_at on audit_log (at desc);
-- Production: grant the app role INSERT and SELECT only on audit_log, so entries cannot be edited or deleted.
