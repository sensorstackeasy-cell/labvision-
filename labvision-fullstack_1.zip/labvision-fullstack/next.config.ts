import type { NextConfig } from "next";

const dev = process.env.NODE_ENV !== "production";
// 'unsafe-inline' for scripts is needed by Next's inline bootstrap scripts. Move to nonce-based CSP for a stricter policy.
const ga = process.env.NEXT_PUBLIC_GA_ID ? " https://www.googletagmanager.com https://www.google-analytics.com" : "";
const csp = [
  "default-src 'self'",
  `img-src 'self' data: blob:${ga}`,
  "style-src 'self' 'unsafe-inline'",
  `script-src 'self' 'unsafe-inline'${dev ? " 'unsafe-eval'" : ""}${ga}`,
  `connect-src 'self'${ga}`,
  "frame-src https://www.youtube-nocookie.com",
  "media-src 'self' https:",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join("; ");

const config: NextConfig = {
  poweredByHeader: false,
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "Content-Security-Policy", value: csp },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
          { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
        ],
      },
    ];
  },
};
export default config;
