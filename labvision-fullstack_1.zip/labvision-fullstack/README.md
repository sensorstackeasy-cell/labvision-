# Labvision MedTech: full-stack website

Public website, staff login, enquiry dashboard, CV uploads and a small CMS for products and certificates.

**Stack:** Next.js 16 (App Router) and TypeScript strict, PostgreSQL via `postgres`, zod validation, bcrypt sessions, nodemailer, optional S3 storage.
Next.js 15 reaches end of life on 21 Oct 2026, so this project starts on 16. Run `npm install`, commit `package-lock.json`, and re-check versions before launch.

## Run locally
```bash
docker compose up -d                 # PostgreSQL 17
cp .env.example .env                 # set ADMIN_EMAIL, ADMIN_PASSWORD (12+ characters) and APP_ENC_KEY (openssl rand -base64 32)
npm install
npm run migrate && npm run seed      # tables (001 and 002), first admin, products, compliance rows
npm run dev                          # http://localhost:3000   admin: /admin
npm run typecheck && npm test        # type-check and unit tests
```

## Everything from the previous website is here
Welcome page on every visit, left slide-out menu, Coming soon labels (site-wide switch plus per-product status), standards chips, "By clinical need" cards, product pages with tabs (overview, how it works, specifications, standards, exploded view), live simulated signals, enlargeable images, datasheet downloads, demo videos (set per product in the admin), related products, catalog page with the complete catalog, service and support, FAQ, distributors form, leadership, careers with CV upload and role buttons, quality and compliance status tables, certificates and documents, contact with hours, response time and Google Maps links, WhatsApp button, privacy policy, optional Google Analytics with a consent banner, structured company data and icon for search engines, quotation, service and document requests.

## New in this version
| Feature | Where |
|---|---|
| Track a request by reference and email (no personal data returned) | `/track`, `api/track` |
| Demo or site-visit booking | `/demo` |
| Department planning guide for monitors and ventilators | `/planner` |
| Tenders and GeM page | `/tenders` |
| News with admin editing (menu link appears once a post is published) | `/news`, admin News |
| Compliance and certificate status editors, issued or in process | admin Compliance, Certificates |
| Site settings, including the Coming soon switch | admin Settings |
| Two-step verification (authenticator app) and password change for staff | admin Security |
| CSV export of enquiries (admin only, spreadsheet-formula safe) | admin Enquiries |
| `sitemap.xml`, `robots.txt` | automatic |

## What is where
| Path | Purpose |
|---|---|
| `src/app/(site)` | Public pages. Products, certificates, compliance, news and the menu read from the database. |
| `src/app/api` | Form, application and tracking endpoints: origin check, rate limit, honeypot, zod validation. |
| `src/app/admin` | Staff login, MFA step and dashboard. `actions.ts` holds every write; each action re-checks the role. |
| `src/lib` | `auth`, `totp`, `secretbox`, `validate`, `files`, `storage`, `mail`, `audit`, `ratelimit`, `planner`, `csv`, `content`. |
| `migrations` | `001_init.sql`, `002_features.sql`. `scripts/seed.ts` loads `seed/*.json` without overwriting CMS edits. |

Roles: **admin** does everything; **sales** sees and updates enquiries only.

## Deploy
1. Managed PostgreSQL (Neon, Supabase, AWS RDS). Set `DATABASE_URL`, then run `npm run migrate && npm run seed` once.
2. Host on Vercel or AWS. Set every variable in `.env.example`; `SITE_URL` must be your real https address. Keep `APP_ENC_KEY` in the host's secret store and back it up: without it staff two-step secrets cannot be read.
3. CVs: private S3 bucket (`S3_BUCKET`, `S3_REGION`) with an IAM role limited to `cv/*`. Without it, files go to local disk, which is for development only.
4. SMTP details for email. Optional: `NEXT_PUBLIC_GA_ID` for analytics.
5. Run behind your own proxy or CDN only: the app reads the client IP from `x-forwarded-for`.

## Receiving enquiries and applications by email
Every enquiry and application is saved in the database first, then emailed to `MAIL_TO` (sales@labvision.co.in). Application emails contain the candidate's details; the CV itself stays in the admin dashboard.
1. **SMTP (recommended):** set `MAIL_TO`, `MAIL_FROM`, `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` from your email provider (use an app password or SMTP credential, not your normal password).
2. **Web3Forms:** set `WEB3FORMS_KEY` (created for sales@labvision.co.in) and leave `SMTP_HOST` empty.
3. Sign in to the admin, open **Settings** and press **Send a test email**. Check the inbox and the spam folder.
If email delivery fails, nothing is lost: the submission is already in the dashboard.

## Security design (short threat model)
| Threat | Control |
|---|---|
| Spam and form abuse | Per-IP rate limits, hidden honeypot field, size limits, origin check. |
| Injection | Parameterised queries everywhere (`postgres` tagged templates), zod schemas on every input, React output escaping. |
| Stolen or guessed staff passwords | bcrypt cost 12, lockout after 5 failures for 15 minutes, login rate limit, audit of every attempt. Add MFA or passkeys next. |
| Session theft | Random 256-bit token, only its SHA-256 stored, HttpOnly + Secure + SameSite=Lax cookie, 8 hour life, server-side revocation. |
| Unauthorised access (IDOR) | `requireUser(roles)` at the top of every admin page and action, deny by default. |
| Malicious CV upload | Type by content and extension, 5 MB cap, random server-made names, private storage, download only by admins, access logged. Add malware scanning. |
| Tampering and accountability | `audit_log` records who did what. In production grant the app role INSERT and SELECT only on that table. |

**Data protection (India DPDP Act 2023):** the forms collect consent, the privacy policy states purpose and retention, and CVs are private. Retention, deletion requests and breach response still need written procedures. This is technical guidance, not legal advice.
**Medical-device context:** this site is not device software, so IEC 62304 does not apply to it. If you later add device dashboards or telemetry, review IEC 62304, IEC 81001-5-1 and ISO 13485 change control first.

## Verification status (be honest about this)
Written in an environment with **no internet**, so dependencies were not installed.
- **Run and passing (23 tests):** CV file checks, rate limiting, text parsing, TOTP against the RFC 6238 test vectors, encryption round trip and tamper detection, planner and CSV safety.
- **Syntax-checked only:** every `.ts` and `.tsx` file parses (74 files).
- **Not run:** `npm install`, `tsc` type-check, `next build`, the zod tests, migrations and seed, login and MFA, form submission, S3, SMTP, the browser components. Run `npm run typecheck && npm test && npm run build` first and fix what they report. CI does this on every push.
- The clickable preview is a separate mock-up with sample data. It shows the intended behaviour, not this code running.

## Not included yet
Passkeys, password reset by email, malware scanning of CVs, Redis rate limits for several servers, nonce-based CSP, Hindi pages, image upload in the CMS (images are files in `public/images`), the planner ratios are placeholders to be confirmed by your clinical team, news is plain text only, uptime monitoring.
